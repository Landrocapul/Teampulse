package com.example.teampulse;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityLogBinding;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class ActivityLogActivity extends AppCompatActivity {

    private ActivityLogBinding binding;
    private FirebaseFirestore db;
    private String projectId;
    private ActivityLogAdapter adapter;
    private List<ActivityLog> logList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = FirebaseFirestore.getInstance();
        projectId = getIntent().getStringExtra("PROJECT_ID");

        if (projectId == null) {
            Toast.makeText(this, "Project ID is missing.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        setupRecyclerView();
        fetchActivityLog();
    }

    private void setupRecyclerView() {
        adapter = new ActivityLogAdapter(this, logList);
        binding.activityLogRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.activityLogRecyclerView.setAdapter(adapter);
    }

    private void fetchActivityLog() {
        binding.progressBar.setVisibility(View.VISIBLE);

        db.collection("projects").document(projectId).collection("activity_log")
                .orderBy("timestamp", Query.Direction.DESCENDING) // Show newest events first
                .limit(50) // Get the 50 most recent events
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    binding.progressBar.setVisibility(View.GONE);
                    logList.clear();
                    logList.addAll(queryDocumentSnapshots.toObjects(ActivityLog.class));
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    binding.progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Failed to load activity log.", Toast.LENGTH_SHORT).show();
                });
    }
}