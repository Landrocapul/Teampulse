package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Map;

public class ReviewTasksAdapter extends RecyclerView.Adapter<ReviewTasksAdapter.TaskViewHolder> {

    private final List<Task> taskList;
    private final Map<String, String> projectIdToTitleMap;
    private final Context context;

    public ReviewTasksAdapter(Context context, List<Task> taskList, Map<String, String> projectIdToTitleMap) {
        this.context = context;
        this.taskList = taskList;
        this.projectIdToTitleMap = projectIdToTitleMap;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item_review_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.bind(task);
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    class TaskViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvTaskTitle;
        private final TextView tvProjectName;
        private final TextView tvAssigneeName;
        private final MaterialButton btnReviewTask;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTaskTitle = itemView.findViewById(R.id.tv_task_title);
            tvProjectName = itemView.findViewById(R.id.tv_project_name);
            tvAssigneeName = itemView.findViewById(R.id.tv_assignee_name);
            btnReviewTask = itemView.findViewById(R.id.btn_review_task);
        }

        public void bind(Task task) {
            tvTaskTitle.setText(task.getTitle());
            tvAssigneeName.setText("Assigned to: " + task.getAssigneeName());

            // Look up the project title from the map
            String projectTitle = projectIdToTitleMap.get(task.getProjectId());
            if (projectTitle != null) {
                tvProjectName.setText("From Project: " + projectTitle);
            } else {
                tvProjectName.setText("From Project: Unknown");
            }

            // Set a click listener to open the project details
            btnReviewTask.setOnClickListener(v -> {
                Intent intent = new Intent(context, ProjectDetailsActivity.class);
                intent.putExtra("PROJECT_ID", task.getProjectId());
                context.startActivity(intent);
            });
        }
    }
}