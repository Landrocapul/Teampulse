package com.example.teampulse;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.ArrayList;
import java.util.List;

public class TasksPagerAdapter extends FragmentStateAdapter {

    private List<String> statuses = new ArrayList<>();
    private List<TaskListFragment> fragments = new ArrayList<>();

    public TasksPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
        
        // Define task statuses with "All" as first tab
        statuses.add("All");
        statuses.add("PLANNING");
        statuses.add("ONGOING");
        statuses.add("TO_REVIEW");
        statuses.add("DONE");
        
        // Create fragments for each status
        for (String status : statuses) {
            fragments.add(TaskListFragment.newInstance(status));
        }
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return fragments.get(position);
    }

    @Override
    public int getItemCount() {
        return statuses.size();
    }

    public String getStatus(int position) {
        return statuses.get(position);
    }

    public TaskListFragment getFragment(int position) {
        return fragments.get(position);
    }

    public void updateFragmentTasks(int position, List<Task> tasks) {
        if (position < fragments.size()) {
            fragments.get(position).updateTasks(tasks);
        }
    }
}
