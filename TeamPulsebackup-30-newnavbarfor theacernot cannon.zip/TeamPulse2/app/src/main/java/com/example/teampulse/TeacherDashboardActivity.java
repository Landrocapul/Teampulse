package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.teampulse.databinding.ActivityTeacherDashboardBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TeacherDashboardActivity extends AppCompatActivity implements NavigationDrawerFragment.NavigationListener, NavigationDrawerFragment.DrawerActivity {

    private ActivityTeacherDashboardBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    private ProjectsAdapter adapter;
    private List<Project> teacherProjects = new ArrayList<>();
    private CustomBottomNavController navController;
    private ListenerRegistration userListener;
    private List<Project> atRiskProjects = new ArrayList<>();
    private List<Project> allProjects = new ArrayList<>();
    private List<Task> allTasks = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTeacherDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setupViews();
        setupToolbarAndDrawer();
        setupBottomNavigation();
        setupQuickAccessCards();
    }

    private void setupViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
        animateQuickAccessCards();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (userListener != null) {
            userListener.remove();
        }
    }

    private void setupToolbarAndDrawer() {
        setSupportActionBar(binding.toolbar);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, binding.toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Host the NavigationDrawerFragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.drawer_fragment_container, new NavigationDrawerFragment())
                .commit();
    }

    private void loadDashboardData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        userListener = db.collection("users").document(currentUser.getUid()).addSnapshotListener((snapshot, e) -> {
            if (e != null) { return; }
            if (snapshot != null && snapshot.exists()) {
                String name = snapshot.getString("name");
                binding.tvWelcome.setText("Welcome, " + name + "!");
                invalidateOptionsMenu(); // Redraw menu to update avatar
            }
        });

        fetchDashboardData(currentUser.getUid());
    }

    private void fetchDashboardData(String teacherId) {
        fetchProjects(teacherId);
        fetchTasks(teacherId);
        fetchAtRiskProjects(teacherId);
    }

    private void fetchProjects(String teacherId) {
        db.collection("projects")
                .whereEqualTo("teacherId", teacherId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    allProjects.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Project project = doc.toObject(Project.class);
                        project.setId(doc.getId());
                        allProjects.add(project);
                    }
                    updateProjectsCard();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load projects.", Toast.LENGTH_SHORT).show();
                });
    }

    private void fetchTasks(String teacherId) {
        db.collection("projects")
                .whereEqualTo("teacherId", teacherId)
                .get()
                .addOnSuccessListener(projectSnapshots -> {
                    allTasks.clear();
                    final int[] completedQueries = {0};
                    final List<String> projectIds = new ArrayList<>();
                    
                    for (QueryDocumentSnapshot doc : projectSnapshots) {
                        projectIds.add(doc.getId());
                    }
                    
                    if (projectIds.isEmpty()) {
                        updateTasksCard();
                        return;
                    }
                    
                    for (String projectId : projectIds) {
                        db.collection("projects").document(projectId).collection("tasks")
                                .get()
                                .addOnSuccessListener(taskSnapshots -> {
                                    for (QueryDocumentSnapshot taskDoc : taskSnapshots) {
                                        Task task = taskDoc.toObject(Task.class);
                                        task.setId(taskDoc.getId());
                                        task.setProjectId(projectId);
                                        allTasks.add(task);
                                    }
                                    completedQueries[0]++;
                                    if (completedQueries[0] == projectIds.size()) {
                                        updateTasksCard();
                                    }
                                })
                                .addOnFailureListener(e -> {
                                    completedQueries[0]++;
                                    if (completedQueries[0] == projectIds.size()) {
                                        updateTasksCard();
                                    }
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load tasks.", Toast.LENGTH_SHORT).show();
                });
    }

    private void setupQuickAccessCards() {
        // Tasks Card Click
        binding.cardTasks.setOnClickListener(v -> {
            startActivity(new Intent(this, TeacherTasksActivity.class));
            finish();
        });

        // Calendar Card Click
        binding.cardCalendar.setOnClickListener(v -> {
            startActivity(new Intent(this, CalendarActivity.class));
            finish();
        });

        // Activity Log Card Click
        binding.cardActivityLog.setOnClickListener(v -> {
            startActivity(new Intent(this, GlobalLogActivity.class));
        });

        // Projects Card Click
        binding.cardProjects.setOnClickListener(v -> {
            startActivity(new Intent(this, TeacherProjectsActivity.class));
            finish();
        });

        // Add click animations to all cards
        setupCardAnimation(binding.cardTasks);
        setupCardAnimation(binding.cardCalendar);
        setupCardAnimation(binding.cardActivityLog);
        setupCardAnimation(binding.cardProjects);
    }

    private void setupCardAnimation(com.google.android.material.card.MaterialCardView card) {
        card.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    animateScale(v, 0.95f);
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    animateScale(v, 1.0f);
                    break;
            }
            return false; // Don't consume the event
        });
    }

    private void animateScale(View view, float scale) {
        view.animate()
                .scaleX(scale)
                .scaleY(scale)
                .setDuration(100)
                .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                .start();
    }

    private void animateQuickAccessCards() {
        // Animate cards with the same timing as at-risk card
        animateCardEntrance(binding.cardTasks, 400);
        animateCardEntrance(binding.cardProjects, 400);
        animateCardEntrance(binding.cardActivityLog, 400);
        animateCardEntrance(binding.cardCalendar, 400);
    }

    private void animateCardEntrance(View view, long delay) {
        // Clear any existing animations
        view.clearAnimation();

        // Set initial state: start from below and fully transparent
        view.setAlpha(0f);
        view.setTranslationY(50f);
        view.setScaleX(0.8f);
        view.setScaleY(0.8f);

        // Animate with scale, fade, and float up effect
        view.animate()
                .alpha(1f)
                .translationY(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(600) // Longer duration for more impact
                .setStartDelay(delay)
                .setInterpolator(new android.view.animation.OvershootInterpolator(0.5f))
                .start();
    }

    private void updateTasksCard() {
        binding.tvTasksCount.setText(allTasks.size() + " tasks");
    }

    private void updateProjectsCard() {
        binding.tvProjectsCount.setText(allProjects.size() + " projects");
    }

    private void fetchAtRiskProjects(String teacherId) {
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        db.collection("projects")
                .whereEqualTo("teacherId", teacherId)
                .whereLessThan("deadline", todayDate)
                .whereLessThan("progress", 100)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    atRiskProjects.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Project project = doc.toObject(Project.class);
                        project.setId(doc.getId());
                        atRiskProjects.add(project);
                    }
                    updateAtRiskPanel();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load at-risk projects.", Toast.LENGTH_SHORT).show();
                    System.err.println("At-Risk Query Failed: " + e.getMessage());
                });
    }

    private void updateAtRiskPanel() {
        int count = atRiskProjects.size();
        
        // Always show the at-risk card for testing (remove this line in production)
        binding.cardAtRiskDetailed.setVisibility(View.VISIBLE);
        
        // Update detailed card (shown only when there are at-risk projects)
        if (count > 0) {
            binding.tvAtRiskCountDetailed.setText(String.valueOf(count));
            binding.btnViewAtRisk.setVisibility(View.VISIBLE);
            binding.btnViewAtRisk.setOnClickListener(v -> {
                Intent intent = new Intent(this, AtRiskProjectsActivity.class);
                intent.putExtra("AT_RISK_PROJECTS", (Serializable) atRiskProjects);
                startActivity(intent);
            });
            
            // Animate the detailed card entrance with the same prominent animation
            animateCardEntrance(binding.cardAtRiskDetailed, 400);
        } else {
            // Show "0" when no at-risk projects
            binding.tvAtRiskCountDetailed.setText("0");
            binding.btnViewAtRisk.setVisibility(View.GONE);
        }
    }

    private void logoutUser() {
        mAuth.signOut();
        Intent intent = new Intent(this, SignInActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            db.collection("users").document(currentUser.getUid()).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            String name = documentSnapshot.getString("name");
                            MenuItem profileItem = menu.findItem(R.id.action_profile);
                            if (profileItem != null) {
                                View actionView = profileItem.getActionView();
                                if (actionView != null) {
                                    TextView avatarTextView = actionView.findViewById(R.id.avatar_text);
                                    if (name != null && !name.isEmpty()) {
                                        String[] names = name.split(" ");
                                        String initials = "";
                                        if (names.length > 0) initials += names[0].charAt(0);
                                        if (names.length > 1) initials += names[names.length - 1].charAt(0);
                                        avatarTextView.setText(initials.toUpperCase());
                                    }
                                    actionView.setOnClickListener(v -> onOptionsItemSelected(profileItem));
                                }
                            }
                        }
                    });
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        int itemId = item.getItemId();
        if (itemId == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupBottomNavigation() {
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        navController = new CustomBottomNavController(this, bottomNav);
        
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection - refresh dashboard
                if (itemId == CustomBottomNavController.NAV_HOME) {
                    // Refresh dashboard data
                    loadDashboardData();
                }
            }
        });
        
        // Set current item to home
        navController.setCurrentItem(CustomBottomNavController.NAV_HOME);
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_MESSAGES, 2);
        navController.showBadge(CustomBottomNavController.NAV_TASKS, 5);
        
        // Animate entry (disabled)
        navController.animateEntry();
    }
    
    private void handleNavigation(int itemId) {
        Intent intent = null;
        
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                // Already in TeacherDashboardActivity - just refresh
                loadDashboardData();
                return;
                
            case CustomBottomNavController.NAV_PROJECTS:
                intent = new Intent(getApplicationContext(), TeacherProjectsActivity.class);
                break;
                
            case CustomBottomNavController.NAV_TASKS:
                intent = new Intent(getApplicationContext(), TeacherTasksActivity.class);
                break;
                
            case CustomBottomNavController.NAV_MESSAGES:
                intent = new Intent(getApplicationContext(), MessagesActivity.class);
                break;
                
            case CustomBottomNavController.NAV_CALENDAR:
                intent = new Intent(this, CalendarActivity.class);
                break;
        }
        
        if (intent != null) {
            startActivity(intent);
            finish();
        }
    }

    @Override
    public void onLogout() {
        logoutUser();
    }

    @Override
    public void onProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onActivityLog() {
        startActivity(new Intent(this, GlobalLogActivity.class));
    }

    @Override
    public void onSettings() {
        Toast.makeText(this, "Settings screen coming soon!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }
}