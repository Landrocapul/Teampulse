package com.example.teampulse;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class TaskListFragment extends Fragment {

    private RecyclerView tasksRecyclerView;
    private TextView tvNoTasks;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TeacherTasksAdapter tasksAdapter;
    private List<Task> taskList;
    private FirebaseFirestore db;
    private String statusFilter;
    private OnRefreshListener refreshListener;

    public interface OnRefreshListener {
        void onRefresh();
    }

    public TaskListFragment() {
        // Required empty public constructor
    }

    public static TaskListFragment newInstance(String statusFilter) {
        TaskListFragment fragment = new TaskListFragment();
        Bundle args = new Bundle();
        args.putString("statusFilter", statusFilter);
        fragment.setArguments(args);
        return fragment;
    }

    public void setOnRefreshListener(OnRefreshListener listener) {
        this.refreshListener = listener;
    }

    public TeacherTasksAdapter getTasksAdapter() {
        return tasksAdapter;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            statusFilter = getArguments().getString("statusFilter");
        }
        db = FirebaseFirestore.getInstance();
        taskList = new ArrayList<>(); // Initialize here
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_task_list, container, false);
        
        tasksRecyclerView = view.findViewById(R.id.tasks_recycler_view);
        tvNoTasks = view.findViewById(R.id.tv_no_tasks);
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);

        // Setup RecyclerView with corrected adapter that supports project dividers
        tasksAdapter = new TeacherTasksAdapter(requireContext(), taskList);
        tasksRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        tasksRecyclerView.setAdapter(tasksAdapter);

        // Setup SwipeRefreshLayout
        swipeRefreshLayout.setOnRefreshListener(() -> {
            if (refreshListener != null) {
                refreshListener.onRefresh();
            }
        });

        // Configure refresh colors
        swipeRefreshLayout.setColorSchemeResources(
            android.R.color.holo_blue_bright,
            android.R.color.holo_green_light,
            android.R.color.holo_orange_light,
            android.R.color.holo_red_light
        );

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        // Show empty state initially
        showNoTasksView();
        
        // If we already have data, update the UI now
        if (taskList != null && !taskList.isEmpty()) {
            android.util.Log.d("TaskListFragment", "View created with existing data, updating UI");
            refreshUI();
        }
    }

    private void refreshUI() {
        if (tasksAdapter != null && tasksRecyclerView != null) {
            // Use setTasks() instead of notifyDataSetChanged() for project dividers
            tasksAdapter.setTasks(taskList);
            android.util.Log.d("TaskListFragment", "Refreshed UI with " + taskList.size() + " tasks");
            android.util.Log.d("TaskListFragment", "Adapter item count after refresh: " + tasksAdapter.getItemCount());
            
            if (taskList.isEmpty()) {
                showNoTasksView();
                android.util.Log.d("TaskListFragment", "Showing no tasks view");
            } else {
                hideNoTasksView();
                android.util.Log.d("TaskListFragment", "Showing tasks view");
            }
        }
    }

    public void updateTasks(List<Task> filteredTasks) {
        android.util.Log.d("TaskListFragment", "Updating tasks for status: " + statusFilter + ", count: " + filteredTasks.size());
        
        if (taskList == null) {
            taskList = new ArrayList<>();
        }
        
        taskList.clear();
        taskList.addAll(filteredTasks);
        
        android.util.Log.d("TaskListFragment", "TaskList size after update: " + taskList.size());
        
        // Only update UI if view is ready
        if (tasksAdapter != null && tasksRecyclerView != null) {
            // Use setTasks() instead of notifyDataSetChanged() for project dividers
            tasksAdapter.setTasks(filteredTasks);
            android.util.Log.d("TaskListFragment", "Called setTasks() with " + filteredTasks.size() + " tasks");
            android.util.Log.d("TaskListFragment", "Adapter item count after setTasks: " + tasksAdapter.getItemCount());
            
            if (taskList.isEmpty()) {
                showNoTasksView();
                android.util.Log.d("TaskListFragment", "Showing no tasks view");
            } else {
                hideNoTasksView();
                android.util.Log.d("TaskListFragment", "Showing tasks view");
            }
        } else {
            android.util.Log.d("TaskListFragment", "View not ready yet, storing data. Adapter: " + (tasksAdapter != null) + ", RecyclerView: " + (tasksRecyclerView != null));
        }
        
        // Stop refreshing
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    private void showNoTasksView() {
        if (tvNoTasks != null) {
            tvNoTasks.setVisibility(View.VISIBLE);
        }
        if (tasksRecyclerView != null) {
            tasksRecyclerView.setVisibility(View.GONE);
        }
    }

    private void hideNoTasksView() {
        if (tvNoTasks != null) {
            tvNoTasks.setVisibility(View.GONE);
        }
        if (tasksRecyclerView != null) {
            tasksRecyclerView.setVisibility(View.VISIBLE);
        }
    }
}
