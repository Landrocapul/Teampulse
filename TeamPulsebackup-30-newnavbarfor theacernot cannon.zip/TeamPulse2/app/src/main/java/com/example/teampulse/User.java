package com.example.teampulse;

public class User {
    private String name;
    private String role;
    private String uid;
    private String teacherId;
    private String teacherCode;
    private String phoneNumber;
    private String department;
    private String pinnedProjectId;

    // Must have a public no-argument constructor for Firestore
    public User() {}

    // --- Getters and Setters ---
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public String getTeacherId() { return teacherId; }
    public void setTeacherId(String teacherId) { this.teacherId = teacherId; }

    public String getTeacherCode() { return teacherCode; }
    public void setTeacherCode(String teacherCode) { this.teacherCode = teacherCode; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }

    public String getPinnedProjectId() { return pinnedProjectId; }
    public void setPinnedProjectId(String pinnedProjectId) { this.pinnedProjectId = pinnedProjectId; }
}