package com.example.teampulse;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GlobalLogActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private GlobalLogAdapter adapter;
    private List<ActivityLog> logList = new ArrayList<>();
    private Map<String, String> projectIdToTitleMap = new HashMap<>();

    // View Binding would be cleaner, but using findViewById for simplicity here
    private androidx.recyclerview.widget.RecyclerView recyclerView;
    private android.widget.ProgressBar progressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_global_log);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.global_log_recycler_view);
        progressBar = findViewById(R.id.progress_bar);

        setupRecyclerView();
        loadAllUserProjectsAndLogs();
    }

    private void setupRecyclerView() {
        adapter = new GlobalLogAdapter(this, logList, projectIdToTitleMap);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }

    private void loadAllUserProjectsAndLogs() {
        progressBar.setVisibility(View.VISIBLE);
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        // Step 1: Get all projects the user is a member of.
        db.collection("projects")
                .whereArrayContains("teamMembers", currentUser.getUid())
                .get()
                .addOnSuccessListener(projectSnapshots -> {
                    List<String> projectIds = new ArrayList<>();
                    projectIdToTitleMap.clear();
                    for (QueryDocumentSnapshot doc : projectSnapshots) {
                        projectIds.add(doc.getId());
                        projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                    }

                    if (projectIds.isEmpty()) {
                        progressBar.setVisibility(View.GONE);
                        return; // No projects, so no logs to fetch.
                    }

                    // Step 2: Perform a collection group query for all logs across all those projects.
                    db.collectionGroup("activity_log")
                            .whereIn("projectId", projectIds) // Firestore needs this field in the log doc
                            .orderBy("timestamp", Query.Direction.DESCENDING)
                            .limit(100) // Get the most recent 100 activities
                            .get()
                            .addOnSuccessListener(logSnapshots -> {
                                logList.clear();
                                for (QueryDocumentSnapshot doc : logSnapshots) {
                                    ActivityLog log = doc.toObject(ActivityLog.class);
                                    // Manually set the projectId on the log object
                                    log.setProjectId(doc.getReference().getParent().getParent().getId());
                                    logList.add(log);
                                }
                                adapter.notifyDataSetChanged();
                                progressBar.setVisibility(View.GONE);
                            })
                            .addOnFailureListener(e -> {
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(this, "Failed to load activity logs.", Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Failed to load projects.", Toast.LENGTH_SHORT).show();
                });
    }
}