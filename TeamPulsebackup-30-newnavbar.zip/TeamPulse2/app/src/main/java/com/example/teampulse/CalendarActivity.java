package com.example.teampulse;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ActivityCalendarBinding;
import com.example.teampulse.databinding.ItemCalendarDayBinding;
import com.example.teampulse.databinding.ItemCalendarMonthHeaderBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.kizitonwose.calendar.core.CalendarDay;
import com.kizitonwose.calendar.core.CalendarMonth;
import com.kizitonwose.calendar.core.DayPosition;
import com.kizitonwose.calendar.view.MonthDayBinder;
import com.kizitonwose.calendar.view.MonthHeaderFooterBinder;
import com.kizitonwose.calendar.view.ViewContainer;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.time.temporal.WeekFields;

public class CalendarActivity extends AppCompatActivity {

    private ActivityCalendarBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String userRole;

    private final List<Task> allTasks = new ArrayList<>();
    private final Map<String, String> projectIdToTitleMap = new HashMap<>();
    private final List<MyTasksListItem> displayedTasks = new ArrayList<>();
    private final Map<LocalDate, List<Task>> tasksByDate = new HashMap<>();
    private final Map<LocalDate, List<Project>> projectsByDeadline = new HashMap<>();

    private CalendarSectionAdapter sectionAdapter;
    private final List<CalendarSectionAdapter.CalendarSectionItem> sections = new ArrayList<>();
    private LocalDate selectedDate = LocalDate.now();
    private final LocalDate today = LocalDate.now();
    private CustomBottomNavController navController;

    private final DateTimeFormatter storageFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private final DateTimeFormatter displayFormatter = DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.getDefault());
    private final DateTimeFormatter monthTitleFormatter = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault());

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCalendarBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setSupportActionBar(binding.toolbar);

        setupRecyclerView();
        setupCalendar();
        fetchUserRoleAndData();
    }
    private void setupCalendar() {
        YearMonth currentMonth = YearMonth.from(selectedDate);
        YearMonth startMonth = currentMonth.minusMonths(12);
        YearMonth endMonth = currentMonth.plusMonths(12);
        final DayOfWeek firstDayOfWeek = WeekFields.of(Locale.getDefault()).getFirstDayOfWeek();

        binding.calendarView.setDayViewResource(R.layout.item_calendar_day);
        binding.calendarView.setMonthHeaderResource(R.layout.item_calendar_month_header);
        binding.calendarView.setup(startMonth, endMonth, firstDayOfWeek);
        binding.calendarView.scrollToMonth(currentMonth);

        binding.calendarView.setDayBinder(new MonthDayBinder<DayViewContainer>() {
            @NonNull
            @Override
            public DayViewContainer create(@NonNull View view) {
                return new DayViewContainer(view);
            }

            @Override
            public void bind(@NonNull DayViewContainer container, @NonNull CalendarDay day) {
                container.day = day;
                LocalDate date = day.getDate();
                ItemCalendarDayBinding dayBinding = container.dayBinding;

                dayBinding.dayText.setText(String.valueOf(date.getDayOfMonth()));

                boolean isCurrentMonth = day.getPosition() == DayPosition.MonthDate;
                dayBinding.getRoot().setAlpha(isCurrentMonth ? 1f : 0.4f);

                List<Task> tasksForDay = tasksByDate.getOrDefault(date, Collections.emptyList());
                List<Project> projectsWithDeadline = projectsByDeadline.getOrDefault(date, Collections.emptyList());
                int taskCount = tasksForDay.size();
                int projectCount = projectsWithDeadline.size();

                if (taskCount == 0 && projectCount == 0) {
                    dayBinding.dot.setVisibility(View.GONE);
                    dayBinding.taskOverflowBadge.setVisibility(View.GONE);
                } else {
                    dayBinding.dot.setVisibility(View.GONE);
                    int totalCount = taskCount + projectCount;
                    dayBinding.taskOverflowBadge.setText(String.valueOf(totalCount));
                    dayBinding.taskOverflowBadge.setVisibility(View.VISIBLE);
                }

                if (date.equals(selectedDate)) {
                    dayBinding.dayText.setBackgroundResource(R.drawable.bg_calendar_selected);
                    dayBinding.dayText.setTextColor(ContextCompat.getColor(CalendarActivity.this, android.R.color.white));
                } else {
                    dayBinding.dayText.setBackgroundResource(0);
                    int textColor = ContextCompat.getColor(CalendarActivity.this,
                            isCurrentMonth ? R.color.text_primary : R.color.text_secondary);
                    dayBinding.dayText.setTextColor(textColor);
                    if (date.equals(today)) {
                        dayBinding.dayText.setTextColor(ContextCompat.getColor(CalendarActivity.this, R.color.blue));
                    }
                }
            }
        });

        binding.calendarView.setMonthHeaderBinder(new MonthHeaderFooterBinder<MonthHeaderViewContainer>() {
            @NonNull
            @Override
            public MonthHeaderViewContainer create(@NonNull View view) {
                return new MonthHeaderViewContainer(view);
            }

            @Override
            public void bind(@NonNull MonthHeaderViewContainer container, @NonNull CalendarMonth month) {
                container.headerBinding.monthTitle.setText(month.getYearMonth().format(monthTitleFormatter));

                LinearLayout dayTitles = container.headerBinding.dayTitlesLayout;
                if (dayTitles.getChildCount() == 0) {
                    dayTitles.setWeightSum(7f);
                    DayOfWeek dayOfWeek = firstDayOfWeek;
                    for (int i = 0; i < 7; i++) {
                        TextView textView = new TextView(dayTitles.getContext());
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                        textView.setLayoutParams(params);
                        textView.setGravity(Gravity.CENTER);
                        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
                        textView.setTextColor(ContextCompat.getColor(CalendarActivity.this, R.color.text_secondary));
                        String label = dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).toUpperCase(Locale.getDefault());
                        textView.setText(label);
                        dayTitles.addView(textView);
                        dayOfWeek = dayOfWeek.plus(1);
                    }
                }
            }
        });

        selectDate(selectedDate, false);
    }

    private void setupRecyclerView() {
        sectionAdapter = new CalendarSectionAdapter(sections, this);
        binding.sectionsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        binding.sectionsRecyclerView.setAdapter(sectionAdapter);
    }

    private void fetchUserRoleAndData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        userRole = documentSnapshot.getString("role");
                    }
                    setupBottomNavigation();
                    loadAllRelevantData();
                });
    }

    private void loadAllRelevantData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        if ("Teacher".equals(userRole)) {
            // For teachers, load projects where they are the teacher
            db.collection("projects")
                    .whereEqualTo("teacherId", currentUser.getUid())
                    .get()
                    .addOnSuccessListener(projectSnapshots -> {
                        projectIdToTitleMap.clear();
                        List<String> projectIds = new ArrayList<>();
                        projectsByDeadline.clear();
                        
                        for (QueryDocumentSnapshot doc : projectSnapshots) {
                            projectIds.add(doc.getId());
                            projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                            
                            // Add project to deadline map
                            Project project = doc.toObject(Project.class);
                            project.setId(doc.getId());
                            if (project.getDeadline() != null && !project.getDeadline().isEmpty()) {
                                try {
                                    LocalDate deadlineDate = LocalDate.parse(project.getDeadline(), storageFormatter);
                                    projectsByDeadline.computeIfAbsent(deadlineDate, key -> new ArrayList<>()).add(project);
                                } catch (Exception e) {
                                    // Skip invalid date formats
                                }
                            }
                        }

                        if (projectIds.isEmpty()) {
                            binding.calendarView.notifyCalendarChanged();
                            selectDate(selectedDate, false);
                            return;
                        }

                        fetchAllTasks(currentUser.getUid(), projectIds);
                    })
                    .addOnFailureListener(e -> {
                        binding.calendarView.notifyCalendarChanged();
                        selectDate(selectedDate, false);
                    });
        } else {
            // For students, load projects where they are team members
            db.collection("projects")
                    .whereArrayContains("teamMembers", currentUser.getUid())
                    .get()
                    .addOnSuccessListener(projectSnapshots -> {
                        projectIdToTitleMap.clear();
                        List<String> projectIds = new ArrayList<>();
                        projectsByDeadline.clear();
                        
                        for (QueryDocumentSnapshot doc : projectSnapshots) {
                            projectIds.add(doc.getId());
                            projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                            
                            // Add project to deadline map
                            Project project = doc.toObject(Project.class);
                            project.setId(doc.getId());
                            if (project.getDeadline() != null && !project.getDeadline().isEmpty()) {
                                try {
                                    LocalDate deadlineDate = LocalDate.parse(project.getDeadline(), storageFormatter);
                                    projectsByDeadline.computeIfAbsent(deadlineDate, key -> new ArrayList<>()).add(project);
                                } catch (Exception e) {
                                    // Skip invalid date formats
                                }
                            }
                        }

                        if (projectIds.isEmpty()) {
                            binding.calendarView.notifyCalendarChanged();
                            selectDate(selectedDate, false);
                            return;
                        }

                        fetchAllTasks(currentUser.getUid(), projectIds);
                    })
                    .addOnFailureListener(e -> {
                        binding.calendarView.notifyCalendarChanged();
                        selectDate(selectedDate, false);
                    });
        }
    }

    private void fetchAllTasks(String userId, List<String> memberProjectIds) {
        Query.Direction direction = Query.Direction.ASCENDING;

        if ("Teacher".equals(userRole)) {
            // For teachers, fetch all tasks in their projects
            allTasks.clear();
            final int[] completedQueries = {0};
            for (String projectId : memberProjectIds) {
                db.collection("projects").document(projectId).collection("tasks")
                        .orderBy("dueDate", direction)
                        .get()
                        .addOnSuccessListener(taskSnapshots -> {
                            for (QueryDocumentSnapshot doc : taskSnapshots) {
                                Task task = doc.toObject(Task.class);
                                task.setId(doc.getId());
                                task.setProjectId(projectId);
                                allTasks.add(task);
                            }
                            completedQueries[0]++;
                            if (completedQueries[0] == memberProjectIds.size()) {
                                rebuildTaskCollections();
                            }
                        })
                        .addOnFailureListener(e -> {
                            completedQueries[0]++;
                            if (completedQueries[0] == memberProjectIds.size()) {
                                rebuildTaskCollections();
                            }
                        });
            }
        } else {
            // For students, fetch tasks assigned to them
            Query tasksQuery = db.collectionGroup("tasks").whereEqualTo("assigneeUid", userId);
            tasksQuery.orderBy("dueDate", direction).get()
                    .addOnSuccessListener(taskSnapshots -> {
                        allTasks.clear();
                        for (QueryDocumentSnapshot doc : taskSnapshots) {
                            Task task = doc.toObject(Task.class);
                            task.setId(doc.getId());
                            String parentProjectId = doc.getReference().getParent().getParent().getId();
                            task.setProjectId(parentProjectId);
                            allTasks.add(task);
                        }
                        rebuildTaskCollections();
                    });
        }
    }

    private void rebuildTaskCollections() {
        tasksByDate.clear();
        for (Task task : allTasks) {
            String dueDate = task.getDueDate();
            if (dueDate == null || dueDate.isEmpty()) continue;
            try {
                LocalDate date = LocalDate.parse(dueDate, storageFormatter);
                tasksByDate.computeIfAbsent(date, key -> new ArrayList<>()).add(task);
            } catch (Exception ignored) { }
        }

        if (!tasksByDate.containsKey(selectedDate) && !tasksByDate.isEmpty()) {
            tasksByDate.keySet().stream().min(LocalDate::compareTo).ifPresent(date -> selectedDate = date);
        }

        binding.calendarView.notifyCalendarChanged();
        selectDate(selectedDate, false);
    }

    private void selectDate(@NonNull LocalDate date, boolean smoothScroll) {
        LocalDate oldDate = selectedDate;
        selectedDate = date;
        updateTasksForSelectedDate(date);
        binding.calendarView.notifyDateChanged(date);
        if (oldDate != null && !oldDate.equals(date)) {
            binding.calendarView.notifyDateChanged(oldDate);
        }
        if (smoothScroll) {
            binding.calendarView.smoothScrollToMonth(YearMonth.from(date));
        }
    }

    private void updateTasksForSelectedDate(@NonNull LocalDate date) {
        List<Task> tasksForDay = tasksByDate.getOrDefault(date, Collections.emptyList());
        List<Project> projectsWithDeadline = projectsByDeadline.getOrDefault(date, Collections.emptyList());

        sections.clear();
        
        // Add project deadlines section
        if (!projectsWithDeadline.isEmpty()) {
            List<MyTasksListItem> deadlineItems = new ArrayList<>();
            for (Project project : projectsWithDeadline) {
                deadlineItems.add(new ProjectDeadlineItem(project));
            }
            sections.add(new CalendarSectionAdapter.CalendarSectionItem(
                CalendarSectionAdapter.TYPE_PROJECT_SECTION, "Project Deadlines", deadlineItems));
        }
        
        // Add tasks grouped by project
        if (!tasksForDay.isEmpty()) {
            Map<String, List<Task>> groupedByProject = new LinkedHashMap<>();
            for (Task task : tasksForDay) {
                groupedByProject.computeIfAbsent(task.getProjectId(), key -> new ArrayList<>()).add(task);
            }

            for (Map.Entry<String, List<Task>> entry : groupedByProject.entrySet()) {
                String projectTitle = projectIdToTitleMap.get(entry.getKey());
                List<MyTasksListItem> taskItems = new ArrayList<>();
                for (Task task : entry.getValue()) {
                    taskItems.add(new TaskItem(task));
                }
                sections.add(new CalendarSectionAdapter.CalendarSectionItem(
                    CalendarSectionAdapter.TYPE_PROJECT_SECTION, 
                    projectTitle != null ? projectTitle : "Project", 
                    taskItems));
            }
        }

        sectionAdapter.notifyDataSetChanged();
    }

    private void setupBottomNavigation() {
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        navController = new CustomBottomNavController(this, bottomNav);
        
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection - refresh calendar
                if (itemId == CustomBottomNavController.NAV_CALENDAR) {
                    // Refresh calendar data
                    loadAllRelevantData();
                }
            }
        });
        
        // Set current item to calendar
        navController.setCurrentItem(CustomBottomNavController.NAV_CALENDAR);
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_MESSAGES, 1);
        navController.showBadge(CustomBottomNavController.NAV_TASKS, 3);
        
        // Animate entry
        navController.animateEntry();
    }
    
    private void handleNavigation(int itemId) {
        Intent intent = null;
        
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                if ("Teacher".equals(userRole)) {
                    intent = new Intent(getApplicationContext(), TeacherDashboardActivity.class);
                } else {
                    intent = new Intent(getApplicationContext(), DashboardActivity.class);
                }
                break;
                
            case CustomBottomNavController.NAV_PROJECTS:
                if ("Teacher".equals(userRole)) {
                    intent = new Intent(getApplicationContext(), TeacherProjectsActivity.class);
                } else {
                    intent = new Intent(getApplicationContext(), ProjectsActivity.class);
                }
                break;
                
            case CustomBottomNavController.NAV_TASKS:
                if ("Teacher".equals(userRole)) {
                    intent = new Intent(getApplicationContext(), TeacherTasksActivity.class);
                } else {
                    intent = new Intent(getApplicationContext(), MyTasksActivity.class);
                }
                break;
                
            case CustomBottomNavController.NAV_MESSAGES:
                intent = new Intent(getApplicationContext(), MessagesActivity.class);
                break;
                
            case CustomBottomNavController.NAV_CALENDAR:
                // Already in CalendarActivity - just refresh
                loadAllRelevantData();
                return;
        }
        
        if (intent != null) {
            startActivity(intent);
            overridePendingTransition(R.anim.float_down_in, R.anim.float_up_out);
            finish();
        }
    }

    private ColorStateList createColorStateList(int selectedColor, int unselectedColor) {
        int[][] states = new int[][] {
            new int[] { android.R.attr.state_checked }, // selected
            new int[] { -android.R.attr.state_checked }  // unselected
        };
        int[] colors = new int[] {
            selectedColor,
            unselectedColor
        };
        return new ColorStateList(states, colors);
    }

    private class DayViewContainer extends ViewContainer {
        final ItemCalendarDayBinding dayBinding;
        CalendarDay day;

        DayViewContainer(@NonNull View view) {
            super(view);
            dayBinding = ItemCalendarDayBinding.bind(view);
            view.setOnClickListener(v -> {
                if (day == null) return;
                if (day.getPosition() == DayPosition.MonthDate) {
                    selectDate(day.getDate(), true);
                } else {
                    binding.calendarView.smoothScrollToMonth(YearMonth.from(day.getDate()));
                }
            });
        }
    }

    private class MonthHeaderViewContainer extends ViewContainer {
        final ItemCalendarMonthHeaderBinding headerBinding;

        MonthHeaderViewContainer(@NonNull View view) {
            super(view);
            headerBinding = ItemCalendarMonthHeaderBinding.bind(view);
        }
    }
}