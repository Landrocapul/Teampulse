package com.example.teampulse;

public class TaskItem implements MyTasksListItem {
    private final Task task;

    public TaskItem(Task task) {
        this.task = task;
    }

    public Task getTask() {
        return task;
    }
}