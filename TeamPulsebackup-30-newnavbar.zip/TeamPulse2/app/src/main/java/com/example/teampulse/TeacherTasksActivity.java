package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class TeacherTasksActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private TextView tvNoTasks;
    private BottomNavigationView bottomNavigation;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private TasksPagerAdapter pagerAdapter;
    private List<Task> allTasks = new ArrayList<>();
    private Map<String, Project> projectMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_tasks);

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            Toast.makeText(this, "You must be logged in to view tasks.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize views
        viewPager = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);
        tvNoTasks = findViewById(R.id.tv_no_tasks);
        bottomNavigation = findViewById(R.id.bottom_navigation);

        // Setup ViewPager and TabLayout
        setupViewPagerAndTabs();

        // Setup bottom navigation
        setupBottomNavigation();

        // Load student tasks
        loadStudentTasks();
    }

    private void setupViewPagerAndTabs() {
        pagerAdapter = new TasksPagerAdapter(this);
        viewPager.setAdapter(pagerAdapter);

        // Setup TabLayout with ViewPager
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            tab.setText(pagerAdapter.getStatus(position));
        }).attach();

        // Add page change listener to update fragments when they become visible
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                // Update the current fragment when page is selected
                String status = pagerAdapter.getStatus(position);
                List<Task> filteredTasks = filterTasksByStatus(status);
                pagerAdapter.updateFragmentTasks(position, filteredTasks);
                
                android.util.Log.d("TeacherTasks", "Page selected: " + status + ", updating with " + filteredTasks.size() + " tasks");
            }
        });

        // Set up refresh listeners for all fragments
        setupRefreshListeners();
    }

    private void setupRefreshListeners() {
        // Set refresh listener for each fragment
        for (int i = 0; i < pagerAdapter.getItemCount(); i++) {
            TaskListFragment fragment = pagerAdapter.getFragment(i);
            if (fragment != null) {
                fragment.setOnRefreshListener(() -> {
                    android.util.Log.d("TeacherTasks", "Refresh triggered");
                    loadStudentTasks(); // Reload all data
                });
            }
        }
    }

    private void setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                startActivity(new Intent(this, TeacherDashboardActivity.class));
                finish();
                return true;
            } else if (itemId == R.id.nav_projects) {
                startActivity(new Intent(this, TeacherProjectsActivity.class));
                finish();
                return true;
            } else if (itemId == R.id.nav_tasks) {
                // Already on tasks page
                return true;
            } else if (itemId == R.id.nav_calendar) {
                startActivity(new Intent(this, CalendarActivity.class));
                finish();
                return true;
            }
            return false;
        });

        // Set current item selected
        bottomNavigation.setSelectedItemId(R.id.nav_tasks);
    }

    private void loadStudentTasks() {
        // Load tasks from all projects where this teacher is linked
        db.collection("projects")
                .whereEqualTo("teacherId", currentUser.getUid())
                .get()
                .addOnSuccessListener(projectQuery -> {
                    if (projectQuery.isEmpty()) {
                        showNoTasksView();
                        return;
                    }

                    // Get all project IDs and store project information
                    List<String> projectIds = new ArrayList<>();
                    Map<String, Project> projectMap = new HashMap<>();
                    
                    for (int i = 0; i < projectQuery.size(); i++) {
                        String projectId = projectQuery.getDocuments().get(i).getId();
                        Project project = projectQuery.getDocuments().get(i).toObject(Project.class);
                        if (project != null) {
                            project.setId(projectId); // Set the document ID
                            projectMap.put(projectId, project);
                        }
                        projectIds.add(projectId);
                    }

                    // Store project map for adapters to use
                    this.projectMap = projectMap;
                    
                    // Load tasks from these projects
                    loadTasksFromProjects(projectIds);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load projects: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    showNoTasksView();
                });
    }

    private void loadTasksFromProjects(List<String> projectIds) {
        if (projectIds.isEmpty()) {
            showNoTasksView();
            return;
        }

        allTasks.clear();
        final java.util.concurrent.atomic.AtomicInteger completedQueries = new java.util.concurrent.atomic.AtomicInteger(0);
        final int totalQueries = projectIds.size();

        // Query tasks from each project's subcollection
        for (String projectId : projectIds) {
            db.collection("projects").document(projectId).collection("tasks")
                    .get()
                    .addOnSuccessListener(taskQuery -> {
                        for (int i = 0; i < taskQuery.size(); i++) {
                            Task task = taskQuery.getDocuments().get(i).toObject(Task.class);
                            if (task != null) {
                                allTasks.add(task);
                            }
                        }

                        int completed = completedQueries.incrementAndGet();
                        if (completed == totalQueries) {
                            // All queries completed, update UI
                            if (allTasks.isEmpty()) {
                                showNoTasksView();
                            } else {
                                // Sort by due date
                                allTasks.sort((t1, t2) -> {
                                    if (t1.getDueDate() == null && t2.getDueDate() == null) return 0;
                                    if (t1.getDueDate() == null) return 1;
                                    if (t2.getDueDate() == null) return -1;
                                    return t1.getDueDate().compareTo(t2.getDueDate());
                                });

                                hideNoTasksView();
                                updateAllFragments();
                            }
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to load tasks", Toast.LENGTH_SHORT).show();
                        int completed = completedQueries.incrementAndGet();
                        if (completed == totalQueries) {
                            if (allTasks.isEmpty()) {
                                showNoTasksView();
                            } else {
                                hideNoTasksView();
                                updateAllFragments();
                            }
                        }
                    });
        }
    }

    private void updateAllFragments() {
        // Update each fragment with filtered tasks immediately when data is loaded
        for (int i = 0; i < pagerAdapter.getItemCount(); i++) {
            TaskListFragment fragment = pagerAdapter.getFragment(i);
            if (fragment != null) {
                // Get the fragment's adapter and set the project map
                TeacherTasksAdapter adapter = fragment.getTasksAdapter();
                if (adapter != null && projectMap != null) {
                    adapter.setProjectMap(projectMap);
                    android.util.Log.d("TeacherTasks", "Set project map for fragment " + i + " with " + projectMap.size() + " projects");
                }
            }
            
            String status = pagerAdapter.getStatus(i);
            List<Task> filteredTasks = filterTasksByStatus(status);
            
            android.util.Log.d("TeacherTasks", "Updating fragment " + i + " (" + status + ") with " + filteredTasks.size() + " tasks");
            
            pagerAdapter.updateFragmentTasks(i, filteredTasks);
        }
    }

    private List<Task> filterTasksByStatus(String status) {
        List<Task> filteredTasks = new ArrayList<>();

        if ("All".equals(status)) {
            filteredTasks.addAll(allTasks);
        } else if ("TO_REVIEW".equals(status)) {
            // Special case: include both FOR_REVIEW and TO_REVIEW
            for (Task task : allTasks) {
                String taskStatus = task.getStatus();
                if (taskStatus != null && (taskStatus.equals("FOR_REVIEW") || taskStatus.equals("TO_REVIEW"))) {
                    filteredTasks.add(task);
                }
            }
        } else {
            // Handle PLANNING, ONGOING, DONE
            for (Task task : allTasks) {
                String taskStatus = task.getStatus();
                if (taskStatus != null && taskStatus.equals(status)) {
                    filteredTasks.add(task);
                }
            }
        }

        return filteredTasks;
    }

    private void showNoTasksView() {
        tvNoTasks.setVisibility(View.VISIBLE);
        viewPager.setVisibility(View.GONE);
        tabLayout.setVisibility(View.GONE);
    }

    private void hideNoTasksView() {
        tvNoTasks.setVisibility(View.GONE);
        viewPager.setVisibility(View.VISIBLE);
        tabLayout.setVisibility(View.VISIBLE);
    }
}
