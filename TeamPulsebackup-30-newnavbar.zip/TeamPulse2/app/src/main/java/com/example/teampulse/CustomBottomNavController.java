package com.example.teampulse;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 * Custom Bottom Navigation Controller
 * Provides Instagram-like bottom navigation with full control over interactions
 */
public class CustomBottomNavController {
    
    // Navigation item IDs
    public static final int NAV_HOME = 0;
    public static final int NAV_PROJECTS = 1;
    public static final int NAV_TASKS = 2;
    public static final int NAV_MESSAGES = 3;
    public static final int NAV_CALENDAR = 4;
    
    private final ConstraintLayout bottomNav;
    private final Context context;
    private final FragmentManager fragmentManager;
    
    // Navigation containers
    private final LinearLayout[] containers = new LinearLayout[5];
    private final ImageView[] icons = new ImageView[5];
    private final TextView[] labels = new TextView[5];
    private final View[] badges = new View[5];
    private final TextView[] badgeCounts = new TextView[5];
    
    // State
    private int currentSelectedItem = NAV_HOME;
    private OnNavigationListener navigationListener;
    
    public interface OnNavigationListener {
        void onNavigationItemSelected(int itemId);
        void onNavigationItemReselected(int itemId);
    }
    
    public CustomBottomNavController(FragmentActivity activity, ConstraintLayout bottomNav) {
        this.bottomNav = bottomNav;
        this.context = bottomNav.getContext();
        this.fragmentManager = activity.getSupportFragmentManager();
        initializeViews();
        setupClickListeners();
        selectItem(NAV_HOME, false);
    }
    
    private void initializeViews() {
        // Initialize all navigation items
        containers[NAV_HOME] = bottomNav.findViewById(R.id.nav_home_container);
        containers[NAV_PROJECTS] = bottomNav.findViewById(R.id.nav_projects_container);
        containers[NAV_TASKS] = bottomNav.findViewById(R.id.nav_tasks_container);
        containers[NAV_MESSAGES] = bottomNav.findViewById(R.id.nav_messages_container);
        containers[NAV_CALENDAR] = bottomNav.findViewById(R.id.nav_calendar_container);
        
        icons[NAV_HOME] = bottomNav.findViewById(R.id.nav_home_icon);
        icons[NAV_PROJECTS] = bottomNav.findViewById(R.id.nav_projects_icon);
        icons[NAV_TASKS] = bottomNav.findViewById(R.id.nav_tasks_icon);
        icons[NAV_MESSAGES] = bottomNav.findViewById(R.id.nav_messages_icon);
        icons[NAV_CALENDAR] = bottomNav.findViewById(R.id.nav_calendar_icon);
        
        labels[NAV_HOME] = bottomNav.findViewById(R.id.nav_home_text);
        labels[NAV_PROJECTS] = bottomNav.findViewById(R.id.nav_projects_text);
        labels[NAV_TASKS] = bottomNav.findViewById(R.id.nav_tasks_text);
        labels[NAV_MESSAGES] = bottomNav.findViewById(R.id.nav_messages_text);
        labels[NAV_CALENDAR] = bottomNav.findViewById(R.id.nav_calendar_text);
        
        badges[NAV_HOME] = bottomNav.findViewById(R.id.nav_home_badge);
        badges[NAV_PROJECTS] = bottomNav.findViewById(R.id.nav_projects_badge);
        badges[NAV_TASKS] = bottomNav.findViewById(R.id.nav_tasks_badge_count);
        badges[NAV_MESSAGES] = bottomNav.findViewById(R.id.nav_messages_badge_count);
        badges[NAV_CALENDAR] = bottomNav.findViewById(R.id.nav_calendar_badge);
        
        badgeCounts[NAV_TASKS] = bottomNav.findViewById(R.id.nav_tasks_badge_count);
        badgeCounts[NAV_MESSAGES] = bottomNav.findViewById(R.id.nav_messages_badge_count);
    }
    
    private void setupClickListeners() {
        containers[NAV_HOME].setOnClickListener(v -> handleNavigationClick(NAV_HOME));
        containers[NAV_PROJECTS].setOnClickListener(v -> handleNavigationClick(NAV_PROJECTS));
        containers[NAV_TASKS].setOnClickListener(v -> handleNavigationClick(NAV_TASKS));
        containers[NAV_MESSAGES].setOnClickListener(v -> handleNavigationClick(NAV_MESSAGES));
        containers[NAV_CALENDAR].setOnClickListener(v -> handleNavigationClick(NAV_CALENDAR));
    }
    
    private void handleNavigationClick(int itemId) {
        // Haptic feedback
        bottomNav.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        
        if (itemId == currentSelectedItem) {
            // Item reselected
            if (navigationListener != null) {
                navigationListener.onNavigationItemReselected(itemId);
            }
            // Animate reselection
            animateReselection(itemId);
        } else {
            // Item selected
            selectItem(itemId, true);
            if (navigationListener != null) {
                navigationListener.onNavigationItemSelected(itemId);
            }
        }
    }
    
    private void selectItem(int itemId, boolean animate) {
        // Reset all items to inactive state
        for (int i = 0; i < 5; i++) {
            setItemInactive(i);
        }
        
        // Set selected item to active state
        setItemActive(itemId);
        
        if (animate) {
            animateSelection(itemId);
        }
        
        currentSelectedItem = itemId;
    }
    
    private void setItemActive(int itemId) {
        icons[itemId].setColorFilter(context.getResources().getColor(R.color.primary));
        labels[itemId].setTextColor(context.getResources().getColor(R.color.primary));
        
        // Scale up active item
        containers[itemId].setScaleX(1.1f);
        containers[itemId].setScaleY(1.1f);
    }
    
    private void setItemInactive(int itemId) {
        icons[itemId].setColorFilter(context.getResources().getColor(R.color.text_secondary));
        labels[itemId].setTextColor(context.getResources().getColor(R.color.text_secondary));
        
        // Reset scale
        containers[itemId].setScaleX(1.0f);
        containers[itemId].setScaleY(1.0f);
    }
    
    private void animateSelection(int itemId) {
        // Scale animation
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(containers[itemId], "scaleX", 0.8f, 1.1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(containers[itemId], "scaleY", 0.8f, 1.1f);
        
        // Fade animation
        ObjectAnimator alpha = ObjectAnimator.ofFloat(containers[itemId], "alpha", 0.5f, 1.0f);
        
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(scaleX, scaleY, alpha);
        animatorSet.setDuration(200);
        animatorSet.start();
    }
    
    private void animateReselection(int itemId) {
        // Bounce animation for reselection
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(containers[itemId], "scaleX", 1.0f, 0.9f, 1.1f, 1.0f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(containers[itemId], "scaleY", 1.0f, 0.9f, 1.1f, 1.0f);
        
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(scaleX, scaleY);
        animatorSet.setDuration(300);
        animatorSet.start();
    }
    
    // Badge management
    public void showBadge(int itemId, int count) {
        if (itemId == NAV_TASKS || itemId == NAV_MESSAGES) {
            // Show numbered badge
            badgeCounts[itemId].setVisibility(View.VISIBLE);
            badgeCounts[itemId].setText(String.valueOf(count));
            if (count > 99) {
                badgeCounts[itemId].setText("99+");
            }
        } else {
            // Show dot badge
            badges[itemId].setVisibility(View.VISIBLE);
        }
    }
    
    public void showDotBadge(int itemId) {
        badges[itemId].setVisibility(View.VISIBLE);
    }
    
    public void hideBadge(int itemId) {
        badges[itemId].setVisibility(View.GONE);
        if (itemId == NAV_TASKS || itemId == NAV_MESSAGES) {
            badgeCounts[itemId].setVisibility(View.GONE);
        }
    }
    
    public void clearAllBadges() {
        for (int i = 0; i < 5; i++) {
            hideBadge(i);
        }
    }
    
    // Animation methods
    public void animateEntry() {
        bottomNav.setTranslationY(bottomNav.getHeight());
        bottomNav.animate()
            .translationY(0)
            .setDuration(400)
            .setInterpolator(new android.view.animation.DecelerateInterpolator())
            .start();
    }
    
    public void animateExit() {
        bottomNav.animate()
            .translationY(bottomNav.getHeight())
            .setDuration(300)
            .setInterpolator(new android.view.animation.AccelerateInterpolator())
            .start();
    }
    
    // State management
    public void setOnNavigationListener(OnNavigationListener listener) {
        this.navigationListener = listener;
    }
    
    public int getCurrentSelectedItem() {
        return currentSelectedItem;
    }
    
    public void setCurrentItem(int itemId) {
        if (itemId >= 0 && itemId < 5) {
            selectItem(itemId, true);
            if (navigationListener != null) {
                navigationListener.onNavigationItemSelected(itemId);
            }
        }
    }
    
    // Enable/disable navigation
    public void setEnabled(boolean enabled) {
        for (LinearLayout container : containers) {
            container.setEnabled(enabled);
            container.setAlpha(enabled ? 1.0f : 0.5f);
        }
    }
    
    // Long press support
    public void setOnLongClickListener(int itemId, View.OnLongClickListener listener) {
        containers[itemId].setOnLongClickListener(listener);
    }
    
    // Custom styling
    public void setIconTint(int itemId, int color) {
        icons[itemId].setColorFilter(color);
    }
    
    public void setLabelText(int itemId, String text) {
        labels[itemId].setText(text);
    }
}
