package com.example.teampulse;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class OnboardingAdapter extends RecyclerView.Adapter<OnboardingAdapter.OnboardingViewHolder> {

    private List<Integer> layouts = new ArrayList<>();
    private Context context;

    public OnboardingAdapter(Context context, List<Integer> layouts) {
        this.context = context;
        this.layouts = layouts;
    }

    @NonNull
    @Override
    public OnboardingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(layouts.get(viewType), parent, false);
        return new OnboardingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OnboardingViewHolder holder, int position) {
        // Handle the Get Started button click on the last page
        if (position == layouts.size() - 1) {
            View btnGetStarted = holder.itemView.findViewById(R.id.btnGetStarted);
            if (btnGetStarted != null) {
                btnGetStarted.setOnClickListener(v -> {
                    if (context instanceof WelcomeActivity) {
                        ((WelcomeActivity) context).resetOnboardingAndNavigateToSignIn();
                    }
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        return layouts.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    static class OnboardingViewHolder extends RecyclerView.ViewHolder {
        public OnboardingViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
