package com.example.teampulse;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.teampulse.databinding.ActivityGroupChatBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupChatActivity extends AppCompatActivity implements MessageAdapter.MessageActionListener {

    private ActivityGroupChatBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String projectId;
    private String currentUserId;
    private String currentUserName;
    private Message replyingToMessage;
    private Message editingMessage; // Track the message being edited

    private List<Message> messageList = new ArrayList<>();
    private MessageAdapter adapter;
    private ListenerRegistration messagesListener;
    private ListenerRegistration typingListener;
    private boolean isFirstLoad = true;

    private final Handler typingHandler = new Handler(Looper.getMainLooper());
    private Runnable typingTimeoutRunnable;
    private boolean isTypingActive = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityGroupChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        projectId = getIntent().getStringExtra("PROJECT_ID");
        if (projectId == null) {
            Toast.makeText(this, "No project ID provided", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }
        currentUserId = currentUser.getUid();

        setupToolbar();
        setupRecyclerView();
        loadCurrentUserName();
        loadMessages();
        setupSendButton();
        setupTypingIndicator();
        binding.btnCancelReply.setOnClickListener(v -> clearReplyState());
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Group Chat");
        }
    }

    private void setupRecyclerView() {
        adapter = new MessageAdapter(messageList, currentUserId, this);
        binding.rvMessages.setLayoutManager(new LinearLayoutManager(this));
        binding.rvMessages.setAdapter(adapter);
    }

    private void loadCurrentUserName() {
        db.collection("users").document(currentUserId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        currentUserName = documentSnapshot.getString("name");
                    }
                });
    }

    private void loadMessages() {
        messagesListener = db.collection("projects").document(projectId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((queryDocumentSnapshots, e) -> {
                    if (e != null) {
                        return;
                    }
                    messageList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Message message = doc.toObject(Message.class);
                        message.setId(doc.getId());
                        if (message.getReadBy() == null) {
                            message.setReadBy(new ArrayList<>());
                        }
                        messageList.add(message);
                        // Don't automatically mark as read - only mark when user actually reads
                    }
                    adapter.notifyDataSetChanged();
                    scrollToBottom();
                    
                    // Mark messages as read only when user first opens the chat
                    if (isFirstLoad) {
                        markAllMessagesAsRead();
                        isFirstLoad = false;
                    }
                });
    }

    private void markAllMessagesAsRead() {
        for (Message message : messageList) {
            if (!message.getSenderId().equals(currentUserId)) {
                boolean alreadyRead = message.getReadBy() != null && message.getReadBy().contains(currentUserId);
                if (!alreadyRead) {
                    Map<String, Object> updates = new HashMap<>();
                    updates.put("status", "read");
                    updates.put("readBy", FieldValue.arrayUnion(currentUserId));
                    db.collection("projects").document(projectId)
                            .collection("messages")
                            .document(message.getId())
                            .update(updates);
                }
            }
        }
    }

    private void setupSendButton() {
        binding.btnSend.setOnClickListener(v -> sendMessage());
    }

    private void sendMessage() {
        String text = binding.etMessage.getText().toString().trim();
        if (text.isEmpty() || currentUserName == null) {
            return;
        }
        
        if (editingMessage != null) {
            // Update existing message
            Map<String, Object> updates = new HashMap<>();
            updates.put("text", text);
            updates.put("edited", true);
            updates.put("isEdited", true);
            updates.put("editedAt", System.currentTimeMillis());
            
            db.collection("projects").document(projectId)
                    .collection("messages")
                    .document(editingMessage.getId())
                    .update(updates)
                    .addOnSuccessListener(aVoid -> {
                        binding.etMessage.setText("");
                        editingMessage = null;
                        binding.btnSend.setIconResource(android.R.drawable.ic_menu_send);
                        binding.btnSend.setTag(null);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to update message", Toast.LENGTH_SHORT).show();
                    });
            return;
        }

        long timestamp = System.currentTimeMillis();
        Message message = new Message(currentUserId, currentUserName, text, timestamp);

        if (replyingToMessage != null) {
            message.setReplyToMessageId(replyingToMessage.getId());
            message.setReplyToSenderName(replyingToMessage.getSenderName());
            String preview = replyingToMessage.getText();
            if (preview != null && preview.length() > 80) {
                preview = preview.substring(0, 80) + "...";
            }
            message.setReplyPreviewText(preview);
        }

        db.collection("projects").document(projectId)
                .collection("messages")
                .add(message)
                .addOnSuccessListener(documentReference -> {
                    binding.etMessage.setText("");
                    documentReference.update("status", "delivered");
                    updateTypingStatus(false, true);
                    clearReplyState();
                    scrollToBottom();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
                });
    }

    
    private void setupTypingIndicator() {
        binding.etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                notifyTyping();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        typingListener = db.collection("projects").document(projectId)
                .collection("typingStatus")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;
                    List<String> typingUsers = new ArrayList<>();
                    snapshots.getDocuments().forEach(doc -> {
                        Boolean typing = doc.getBoolean("typing");
                        if (Boolean.TRUE.equals(typing) && !doc.getId().equals(currentUserId)) {
                            String name = doc.getString("name");
                            typingUsers.add(name != null ? name : "Someone");
                        }
                    });

                    if (typingUsers.isEmpty()) {
                        binding.tvTypingIndicator.setVisibility(View.GONE);
                    } else {
                        StringBuilder builder = new StringBuilder();
                        for (int i = 0; i < typingUsers.size(); i++) {
                            if (i > 0) builder.append(", ");
                            builder.append(typingUsers.get(i));
                        }
                        String message = typingUsers.size() == 1
                                ? builder + " is typing..."
                                : builder + " are typing...";
                        binding.tvTypingIndicator.setVisibility(View.VISIBLE);
                        binding.tvTypingIndicator.setText(message);
                    }
                });
    }

    private void notifyTyping() {
        updateTypingStatus(true, false);
        if (typingTimeoutRunnable != null) {
            typingHandler.removeCallbacks(typingTimeoutRunnable);
        }
        typingTimeoutRunnable = () -> updateTypingStatus(false, false);
        typingHandler.postDelayed(typingTimeoutRunnable, 2000);
    }

    private void updateTypingStatus(boolean typing, boolean force) {
        if (projectId == null || currentUserId == null) return;
        if (!force && isTypingActive == typing) return;
        isTypingActive = typing;

        Map<String, Object> data = new HashMap<>();
        data.put("typing", typing);
        data.put("name", currentUserName != null ? currentUserName : "Someone");
        data.put("updatedAt", System.currentTimeMillis());
        db.collection("projects").document(projectId)
                .collection("typingStatus")
                .document(currentUserId)
                .set(data, SetOptions.merge());
    }

    private void startReplyToMessage(Message message) {
        replyingToMessage = message;
        binding.replyPreviewContainer.setVisibility(View.VISIBLE);
        binding.tvReplySender.setText(message.getSenderName() != null ? message.getSenderName() : "Unknown");
        String preview = message.getText();
        if (preview != null && preview.length() > 80) {
            preview = preview.substring(0, 80) + "...";
        }
        binding.tvReplyPreview.setText(preview != null ? preview : "");
    }

    private void clearReplyState() {
        replyingToMessage = null;
        binding.replyPreviewContainer.setVisibility(View.GONE);
        binding.tvReplySender.setText("");
        binding.tvReplyPreview.setText("");
    }
    
    @Override
    public void onReply(Message message) {
        startReplyToMessage(message);
    }
    
    @Override
    public void onEdit(Message message) {
        if (message == null || message.isDeleted()) return;
        
        editingMessage = message;
        binding.etMessage.setText(message.getText());
        binding.etMessage.setSelection(message.getText().length());
        binding.etMessage.requestFocus();
        binding.btnSend.setIconResource(R.drawable.ic_update);
        binding.btnSend.setTag("update");
    }
    
    @Override
    public void onDelete(Message message) {
        if (message == null || message.isDeleted()) return;
        
        new android.app.AlertDialog.Builder(this)
            .setTitle("Delete Message")
            .setMessage("Are you sure you want to delete this message?")
            .setPositiveButton("Delete", (dialog, which) -> deleteMessage(message))
            .setNegativeButton("Cancel", null)
            .show();
    }
    
    private void deleteMessage(Message message) {
        if (message.getId() == null) return;
        
        Map<String, Object> updates = new HashMap<>();
        updates.put("deleted", true);
        updates.put("text", "This message was deleted");
        updates.put("isDeleted", true);
        
        db.collection("projects").document(projectId)
                .collection("messages")
                .document(message.getId())
                .update(updates)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Message deleted", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to delete message", Toast.LENGTH_SHORT).show();
                });
    }

    private void scrollToBottom() {
        if (adapter.getItemCount() > 0) {
            binding.rvMessages.scrollToPosition(adapter.getItemCount() - 1);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (messagesListener != null) {
            messagesListener.remove();
        }
        if (typingListener != null) {
            typingListener.remove();
        }
        updateTypingStatus(false, true);
        if (typingTimeoutRunnable != null) {
            typingHandler.removeCallbacks(typingTimeoutRunnable);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
