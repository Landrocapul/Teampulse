package com.example.teampulse;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class LogHelper {

    private static final FirebaseFirestore db = FirebaseFirestore.getInstance();
    private static final FirebaseAuth mAuth = FirebaseAuth.getInstance();


    public static void logActivity(String projectId, String logMessage, ActivityLog.EventType eventType) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || projectId == null) {
            return; // Cannot log if user is not signed in or project is unknown
        }

        // Use the display name, fall back to email if name is not set
        String authorName = currentUser.getDisplayName();
        if (authorName == null || authorName.isEmpty()) {
            authorName = currentUser.getEmail();
        }

        String authorUid = currentUser.getUid();

        ActivityLog logEntry = new ActivityLog(logMessage, eventType, authorName, authorUid);
        logEntry.setProjectId(projectId);

        // Add the log entry to the 'activity_log' sub-collection of the specific project
        db.collection("projects").document(projectId)
                .collection("activity_log")
                .add(logEntry); // .add() automatically generates a unique ID
    }
}