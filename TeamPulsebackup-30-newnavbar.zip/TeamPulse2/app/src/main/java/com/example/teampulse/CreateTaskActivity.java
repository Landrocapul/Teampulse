package com.example.teampulse;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.teampulse.databinding.ActivityCreateTaskBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class CreateTaskActivity extends AppCompatActivity {

    private ActivityCreateTaskBinding binding;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String projectId;
    private ArrayAdapter<String> membersAdapter;
    private Map<String, String> memberNameToUidMap = new HashMap<>();
    private List<String> memberNames = new ArrayList<>();

    // ✅ New variables to manage Edit Mode
    private boolean isEditMode = false;
    private String editTaskId;
    private Task existingTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateTaskBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // ✅ Check if we are in "Create" or "Edit" mode
        if (getIntent().hasExtra("EDIT_TASK_ID")) {
            isEditMode = true;
            editTaskId = getIntent().getStringExtra("EDIT_TASK_ID");
        }
        projectId = getIntent().getStringExtra("PROJECT_ID");

        setupToolbar();
        setupDropdownMenus();
        fetchProjectMembers(); // This will also trigger populating data in edit mode

        binding.taskDueDateEditText.setOnClickListener(v -> showDatePicker());
        binding.createTaskButton.setOnClickListener(v -> saveTask());
        binding.cancelTaskButton.setOnClickListener(v -> finish());
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        // ✅ Dynamically set the title based on the mode
        if (isEditMode) {
            binding.toolbar.setTitle("Edit Task");
        } else {
            binding.toolbar.setTitle("Create New Task");
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void setupDropdownMenus() {
        ArrayAdapter<CharSequence> typeAdapter = ArrayAdapter.createFromResource(
                this, R.array.task_type_array, android.R.layout.simple_spinner_item);
        binding.taskTypeAutoCompleteTextView.setAdapter(typeAdapter);

        ArrayAdapter<CharSequence> pointsAdapter = ArrayAdapter.createFromResource(
                this, R.array.task_points_array, android.R.layout.simple_spinner_item);
        binding.pointsAutoCompleteTextView.setAdapter(pointsAdapter);

        membersAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, memberNames);
        binding.assigneeAutoCompleteTextView.setAdapter(membersAdapter);
    }

    private void fetchProjectMembers() {
        db.collection("projects").document(projectId).get()
                .addOnSuccessListener(projectSnapshot -> {
                    if (projectSnapshot.exists()) {
                        List<String> memberUids = (List<String>) projectSnapshot.get("teamMembers");
                        if (memberUids != null && !memberUids.isEmpty()) {
                            db.collection("users").whereIn("uid", memberUids).get()
                                    .addOnSuccessListener(usersSnapshot -> {
                                        memberNames.clear();
                                        memberNameToUidMap.clear();
                                        for (DocumentSnapshot userDoc : usersSnapshot.getDocuments()) {
                                            String name = userDoc.getString("name");
                                            String uid = userDoc.getString("uid");
                                            if (name != null && uid != null) {
                                                memberNames.add(name);
                                                memberNameToUidMap.put(name, uid);
                                            }
                                        }
                                        membersAdapter.notifyDataSetChanged();

                                        // ✅ If in edit mode, now that we have the members, fetch the task data
                                        if (isEditMode) {
                                            loadTaskData();
                                        }
                                    });
                        }
                    }
                });
    }

    // ✅ NEW METHOD: Fetches the existing task data from Firestore
    private void loadTaskData() {
        db.collection("projects").document(projectId).collection("tasks").document(editTaskId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        existingTask = documentSnapshot.toObject(Task.class);
                        if (existingTask != null) {
                            populateFieldsForEdit();
                        }
                    } else {
                        Toast.makeText(this, "Error: Task not found.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
    }

    // ✅ NEW METHOD: Pre-fills all the form fields with the loaded task data
    private void populateFieldsForEdit() {
        binding.taskTitleEditText.setText(existingTask.getTitle());
        binding.taskDescriptionEditText.setText(existingTask.getDescription());
        binding.taskDueDateEditText.setText(existingTask.getDueDate());

        // Set dropdowns by value, not by position
        binding.taskTypeAutoCompleteTextView.setText(existingTask.getType(), false);
        binding.pointsAutoCompleteTextView.setText(String.valueOf(existingTask.getPoints()), false);
        binding.assigneeAutoCompleteTextView.setText(existingTask.getAssigneeName(), false);

        // Change the button text
        binding.createTaskButton.setText("Save Changes");
    }

    // ✅ RENAMED & MODIFIED: This method now handles both creating and updating
    private void saveTask() {
        if (mAuth.getCurrentUser() == null) {
            Toast.makeText(this, "User not signed in", Toast.LENGTH_SHORT).show();
            return;
        }

        String title = Objects.requireNonNull(binding.taskTitleEditText.getText()).toString().trim();
        String description = Objects.requireNonNull(binding.taskDescriptionEditText.getText()).toString().trim();
        String assigneeName = binding.assigneeAutoCompleteTextView.getText().toString().trim();
        String dueDate = Objects.requireNonNull(binding.taskDueDateEditText.getText()).toString().trim();
        String taskType = binding.taskTypeAutoCompleteTextView.getText().toString();
        String pointsString = binding.pointsAutoCompleteTextView.getText().toString();

        if (title.isEmpty() || assigneeName.isEmpty() || dueDate.isEmpty() || taskType.isEmpty() || pointsString.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String assigneeUid = memberNameToUidMap.get(assigneeName);
        if (assigneeUid == null) {
            Toast.makeText(this, "Please select a valid team member from the list.", Toast.LENGTH_SHORT).show();
            return;
        }

        int pointsValue = Integer.parseInt(pointsString);

        Map<String, Object> task = new HashMap<>();
        task.put("title", title);
        task.put("description", description);
        task.put("assigneeName", assigneeName);
        task.put("assigneeUid", assigneeUid);
        task.put("dueDate", dueDate);
        task.put("type", taskType);
        task.put("points", pointsValue);
        // Only add creation-specific fields if we are NOT in edit mode
        if (!isEditMode) {
            task.put("createdDate", new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                    .format(Calendar.getInstance().getTime()));
            task.put("status", TaskStatus.PLANNING.name());
            task.put("projectId", projectId);
        }

        if (isEditMode) {
            // ✅ UPDATE logic
            DocumentReference taskRef = db.collection("projects").document(projectId).collection("tasks").document(editTaskId);
            taskRef.update(task)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Task updated successfully!", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to update task: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        } else {
            // CREATE logic
            db.collection("projects").document(projectId).collection("tasks").add(task)
                    .addOnSuccessListener(docRef -> {
                        // ✅ A new task was created! Log it.
                        String logMessage = "created a new task: '" + title + "'.";
                        LogHelper.logActivity(projectId, logMessage, ActivityLog.EventType.TASK_CREATED);

                        Toast.makeText(this, "Task created successfully!", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to create task: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String date = String.format(Locale.getDefault(), "%04d-%02d-%02d",
                            year, month + 1, dayOfMonth);
                    binding.taskDueDateEditText.setText(date);
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }
}