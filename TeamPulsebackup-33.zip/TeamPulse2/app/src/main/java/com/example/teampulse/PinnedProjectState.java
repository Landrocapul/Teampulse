package com.example.teampulse;

// UI State class for the pinned project
public abstract class PinnedProjectState {
    public static class Loading extends PinnedProjectState {}
    public static class Empty extends PinnedProjectState {}
    public static class Success extends PinnedProjectState {
        public final Project project;
        public Success(Project project) { this.project = project; }
    }
    public static class Error extends PinnedProjectState {
        public final String message;
        public Error(String message) { this.message = message; }
    }
}
