package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.teampulse.databinding.ActivityDashboardBinding;
import com.example.teampulse.databinding.ProjectCardBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity implements NavigationDrawerFragment.NavigationListener, NavigationDrawerFragment.DrawerActivity {

    private ActivityDashboardBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private CustomBottomNavController navController;

    private Handler pinnedProjectHandler = new Handler(Looper.getMainLooper());
    private Runnable hidePinnedProjectDetailsRunnable;

    interface OnProgressFetchedListener {
        void onFetched();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setupViews();
        setupToolbarAndDrawer();
        setupBottomNavigation();
        setupShortcuts();
    }

    private void setupViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    private void setupShortcuts() {
        // Calendar shortcut
        binding.cardCalendarShortcut.setOnClickListener(v -> {
            startActivity(new Intent(this, CalendarActivity.class));
        });
        animateCardEntrance(binding.cardCalendarShortcut);
        setupCardClickAnimation(binding.cardCalendarShortcut);

        // Messages shortcut
        binding.cardMessagesShortcut.setOnClickListener(v -> {
            startActivity(new Intent(this, MessagesActivity.class));
        });
        animateCardEntrance(binding.cardMessagesShortcut);
        setupCardClickAnimation(binding.cardMessagesShortcut);

        // Activity Log shortcut
        binding.cardActivityLogShortcut.setOnClickListener(v -> {
            startActivity(new Intent(this, GlobalLogActivity.class));
        });
        animateCardEntrance(binding.cardActivityLogShortcut);
        setupCardClickAnimation(binding.cardActivityLogShortcut);

        // Task Review shortcut
        binding.cardTaskReviewShortcut.setOnClickListener(v -> {
            startActivity(new Intent(this, ReviewTasksActivity.class));
        });
        animateCardEntrance(binding.cardTaskReviewShortcut);
        setupCardClickAnimation(binding.cardTaskReviewShortcut);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupDashboardDataListener();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (hidePinnedProjectDetailsRunnable != null) {
            pinnedProjectHandler.removeCallbacks(hidePinnedProjectDetailsRunnable);
        }
    }

    private void setupToolbarAndDrawer() {
        setSupportActionBar(binding.toolbar);
        
        // Hide the default toolbar title to prevent duplicate text
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        toggle = new ActionBarDrawerToggle(this, drawerLayout, binding.toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Host the NavigationDrawerFragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.drawer_fragment_container, new NavigationDrawerFragment())
                .commit();
    }

    private void setupDashboardDataListener() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        db.collection("users").document(currentUser.getUid()).addSnapshotListener((snapshot, e) -> {
            if (e != null) {
                return;
            }
            if (snapshot != null && snapshot.exists()) {
                String name = snapshot.getString("name");
                binding.tvWelcome.setText("Welcome back, " + name + "!");
                invalidateOptionsMenu();

                String pinnedId = snapshot.getString("pinnedProjectId");
                if (pinnedId != null && !pinnedId.isEmpty()) {
                    loadAndDisplayPinnedProject(pinnedId);
                } else {
                    binding.pinnedProjectCard.getRoot().setVisibility(View.GONE);
                    binding.tvNoPinnedProject.setVisibility(View.VISIBLE);
                }

                String role = snapshot.getString("role");
                if ("Student".equals(role)) {
                    binding.cardJoinProject.setVisibility(View.VISIBLE);
                    // Apply the same animation as pinned project
                    animateCardEntrance(binding.cardJoinProject);
                    // Add click animation feedback
                    setupCardClickAnimation(binding.cardJoinProject);
                    binding.btnJoinProject.setOnClickListener(v -> showJoinProjectDialog());
                    fetchTasksToReviewCount(currentUser.getUid());
                } else if ("Teacher".equals(role)) {
                    binding.cardJoinProject.setVisibility(View.VISIBLE);
                    // Apply the same animation as pinned project
                    animateCardEntrance(binding.cardJoinProject);
                    // Add click animation feedback
                    setupCardClickAnimation(binding.cardJoinProject);
                    binding.btnJoinProject.setOnClickListener(v -> showJoinProjectDialog());
                    fetchTasksToReviewCount(currentUser.getUid());
                } else {
                    binding.cardJoinProject.setVisibility(View.VISIBLE);
                    // Apply the same animation as pinned project
                    animateCardEntrance(binding.cardJoinProject);
                    // Add click animation feedback
                    setupCardClickAnimation(binding.cardJoinProject);
                    binding.btnJoinProject.setOnClickListener(v -> showJoinProjectDialog());
                }
            }
        });
    }

    private void fetchTasksToReviewCount(String leaderId) {
        db.collection("projects").whereEqualTo("leaderId", leaderId).get()
                .addOnSuccessListener(projectSnapshots -> {
                    if (projectSnapshots.isEmpty()) {
                        updateReviewCard(0);
                        return;
                    }
                    List<String> projectIds = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : projectSnapshots) {
                        projectIds.add(doc.getId());
                    }
                    if (!projectIds.isEmpty()) {
                        db.collectionGroup("tasks")
                                .whereIn("projectId", projectIds)
                                .whereEqualTo("status", "FOR_REVIEW")
                                .get()
                                .addOnSuccessListener(taskSnapshots -> updateReviewCard(taskSnapshots.size()));
                    }
                });
    }

    private void updateReviewCard(int count) {
        // Update the badge on the task review shortcut
        if (count > 0) {
            binding.tvTaskReviewBadge.setText(String.valueOf(count));
            binding.tvTaskReviewBadge.setVisibility(View.VISIBLE);
        } else {
            binding.tvTaskReviewBadge.setVisibility(View.GONE);
        }
    }

    private void showJoinProjectDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Join a Project");
        builder.setMessage("Enter the 6-character join code:");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        input.setHint("ABC123");
        builder.setView(input);
        builder.setPositiveButton("Join", (dialog, which) -> {
            String code = input.getText().toString().trim().toUpperCase();
            if (code.length() == 6) {
                joinProjectWithCode(code);
            } else {
                Toast.makeText(this, "Please enter a valid 6-character code.", Toast.LENGTH_SHORT).show();
            }
        });



        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();

    }

    private void joinProjectWithCode(String code) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;
        db.collection("projects").whereEqualTo("joinCode", code).limit(1).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(this, "Project not found.", Toast.LENGTH_LONG).show();
                    } else {
                        String projectId = queryDocumentSnapshots.getDocuments().get(0).getId();
                        db.collection("projects").document(projectId)
                                .update("teamMembers", FieldValue.arrayUnion(currentUser.getUid()))
                                .addOnSuccessListener(aVoid -> {
                                    // ✅ A member joined! Log it.
                                    String logMessage = "joined the project.";
                                    LogHelper.logActivity(projectId, logMessage, ActivityLog.EventType.MEMBER_JOINED);

                                    Toast.makeText(this, "Successfully joined project!", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(this, ProjectsActivity.class));
                                });
                    }
                });
    }

    private void logoutUser() {
        mAuth.signOut();
        Intent intent = new Intent(this, SignInActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void loadAndDisplayPinnedProject(String projectId) {
        db.collection("projects").document(projectId).get()
                .addOnSuccessListener(doc -> {
                    if (doc.exists()) {
                        binding.pinnedProjectCard.getRoot().setVisibility(View.VISIBLE);
                        binding.tvNoPinnedProject.setVisibility(View.GONE);
                        Project project = doc.toObject(Project.class);
                        if (project == null) return;
                        project.setId(doc.getId());
                        ProjectCardBinding cardBinding = binding.pinnedProjectCard;
                        cardBinding.tvLeaderName.setText("Led by " + project.getLeaderName());
                        cardBinding.projectTitleText.setText(project.getTitle());
                        cardBinding.tvJoinCode.setText("Join Code: " + project.getJoinCode());
                        cardBinding.tvTotalPoints.setText(project.getTotalPoints() + " Total Points");
                        cardBinding.projectDescriptionText.setText(project.getDescription());
                        cardBinding.projectDeadlineText.setText("Deadline: " + project.getDeadline());
                        int progress = (int) project.getProgress();
                        cardBinding.projectProgressText.setText(progress + "%");
                        cardBinding.defaultProgressBar.setProgress(progress);
                        // Show progress bar segments and legend by default
                        cardBinding.progressBarSegmentsContainer.removeAllViews();
                        cardBinding.legendContainer.setVisibility(View.VISIBLE);
                        
                        // Fetch and display segmented progress immediately
                        fetchAndDisplaySegmentedProgress(project.getId(), 
                            cardBinding.progressBarSegmentsContainer,
                            cardBinding.legendContainer,
                            project.getTotalPoints(),
                            () -> {
                                // Progress loaded callback
                            });
                            // Remove the auto-hide functionality
                            hidePinnedProjectDetailsRunnable = null;
                        cardBinding.btnPinProject.setVisibility(View.GONE);
                        cardBinding.btnDeleteProject.setVisibility(View.GONE);
                        cardBinding.openProjectButton.setVisibility(View.GONE);
                        cardBinding.btnOpenProjectIcon.setVisibility(View.VISIBLE);
                        cardBinding.btnOpenProjectIcon.setOnClickListener(v -> {
                            Intent intent = new Intent(this, ProjectDetailsActivity.class);
                            intent.putExtra("PROJECT_ID", project.getId());
                            startActivity(intent);
                        });

                        cardBinding.btnChatProject.setOnClickListener(v -> {
                            Intent intent = new Intent(this, GroupChatActivity.class);
                            intent.putExtra("PROJECT_ID", project.getId());
                            startActivity(intent);
                        });

                        // Add fade-in entrance animation to the card
                        animateCardEntrance(cardBinding.getRoot());

                        // Add click animation feedback
                        setupCardClickAnimation(cardBinding.getRoot());
                    } else {
                        binding.pinnedProjectCard.getRoot().setVisibility(View.GONE);
                        binding.tvNoPinnedProject.setVisibility(View.VISIBLE);
                    }
                });
    }

    private void animateCardEntrance(View cardView) {
        // Clear any existing animations
        cardView.clearAnimation();

        // Set initial state: start from slightly below and fully transparent
        cardView.setAlpha(0f);
        cardView.setTranslationY(30f); // Small upward float from 30px below

        // Animate fade-in while floating up to position
        cardView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(500) // Slightly longer for smoother fade
                .setStartDelay(200) // Small delay for dashboard entrance
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .start();
    }

    private void setupCardClickAnimation(View cardView) {
        cardView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    animateScale(v, 0.95f);
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    animateScale(v, 1.0f);
                    break;
            }
            return false; // Don't consume the event
        });
    }

    private void animateScale(View view, float scale) {
        view.animate()
                .scaleX(scale)
                .scaleY(scale)
                .setDuration(100)
                .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                .start();
    }

    private void fetchAndDisplaySegmentedProgress(String projectId, LinearLayout progressBarContainer, com.google.android.flexbox.FlexboxLayout legendContainer, int totalProjectPoints, OnProgressFetchedListener onCompleteListener) {
        db.collection("projects").document(projectId).collection("tasks").get()
                .addOnSuccessListener(taskSnapshots -> {
                    if (taskSnapshots.isEmpty()) { if (onCompleteListener != null) onCompleteListener.onFetched(); return; }
                    int completedResearchPoints = 0, completedDevPoints = 0, completedDocsPoints = 0, completedPresentPoints = 0;
                    for (QueryDocumentSnapshot doc : taskSnapshots) {
                        Task task = doc.toObject(Task.class);
                        if (task.getStatusEnum() == TaskStatus.DONE) {
                            int points = task.getPoints();
                            String type = task.getType() != null ? task.getType() : "";
                            switch (type) {
                                case "Research": completedResearchPoints += points; break;
                                case "Development": completedDevPoints += points; break;
                                case "Documentation": completedDocsPoints += points; break;
                                case "Presentation": completedPresentPoints += points; break;
                            }
                        }
                    }
                    if (totalProjectPoints == 0) { if (onCompleteListener != null) onCompleteListener.onFetched(); return; }
                    int researchPct = (int) (((double) completedResearchPoints / totalProjectPoints) * 100);
                    int devPct = (int) (((double) completedDevPoints / totalProjectPoints) * 100);
                    int docsPct = (int) (((double) completedDocsPoints / totalProjectPoints) * 100);
                    int presentPct = (int) (((double) completedPresentPoints / totalProjectPoints) * 100);
                    updateSegmentedProgressBar(progressBarContainer, researchPct, devPct, docsPct, presentPct);
                    updateLegend(legendContainer, researchPct, devPct, docsPct, presentPct);
                    if (onCompleteListener != null) onCompleteListener.onFetched();
                })
                .addOnFailureListener(e -> {
                    if (onCompleteListener != null) onCompleteListener.onFetched();
                });
    }

    private void updateSegmentedProgressBar(LinearLayout container, int... percentages) {
        container.removeAllViews();
        int[] colors = {R.color.progress_research, R.color.progress_development, R.color.progress_documentation, R.color.progress_presentation};
        for (int i = 0; i < percentages.length; i++) {
            if (percentages[i] > 0) {
                View view = new View(this);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, percentages[i]);
                view.setLayoutParams(params);
                GradientDrawable drawable = (GradientDrawable) ContextCompat.getDrawable(this, R.drawable.progress_bar_segment).mutate();
                drawable.setColor(ContextCompat.getColor(this, colors[i]));
                view.setBackground(drawable);
                container.addView(view);
            }
        }
    }

    private LinearLayout createLegendItem(Context context, String label, int colorRes) {
        LinearLayout itemLayout = new LinearLayout(context);
        itemLayout.setOrientation(LinearLayout.HORIZONTAL);
        itemLayout.setGravity(Gravity.CENTER_VERTICAL);
        com.google.android.flexbox.FlexboxLayout.LayoutParams params = new com.google.android.flexbox.FlexboxLayout.LayoutParams(
                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT,
                com.google.android.flexbox.FlexboxLayout.LayoutParams.WRAP_CONTENT);
        final float scale = getResources().getDisplayMetrics().density;
        int marginEndPx = (int) (16 * scale + 0.5f);
        int marginBottomPx = (int) (4 * scale + 0.5f);
        params.setMarginEnd(marginEndPx);
        params.bottomMargin = marginBottomPx;
        itemLayout.setLayoutParams(params);
        View colorBox = new View(context);
        int boxSize = (int) (12 * scale);
        LinearLayout.LayoutParams boxParams = new LinearLayout.LayoutParams(boxSize, boxSize);
        boxParams.setMarginEnd((int)(8 * scale));
        colorBox.setLayoutParams(boxParams);
        colorBox.setBackgroundColor(ContextCompat.getColor(context, colorRes));
        itemLayout.addView(colorBox);
        TextView textView = new TextView(context);
        textView.setText(label);
        textView.setTextSize(12);
        textView.setTextColor(ContextCompat.getColor(context, R.color.gray));
        itemLayout.addView(textView);
        return itemLayout;
    }

    private void updateLegend(com.google.android.flexbox.FlexboxLayout legendContainer, int researchPct, int devPct, int docsPct, int presentPct) {
        legendContainer.removeAllViews();
        if (researchPct > 0) legendContainer.addView(createLegendItem(this, "Research", R.color.progress_research));
        if (devPct > 0) legendContainer.addView(createLegendItem(this, "Development", R.color.progress_development));
        if (docsPct > 0) legendContainer.addView(createLegendItem(this, "Documentation", R.color.progress_documentation));
        if (presentPct > 0) legendContainer.addView(createLegendItem(this, "Presentation", R.color.progress_presentation));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            db.collection("users").document(currentUser.getUid()).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            String name = documentSnapshot.getString("name");
                            MenuItem profileItem = menu.findItem(R.id.action_profile);
                            if (profileItem != null) {
                                View actionView = profileItem.getActionView();
                                if (actionView != null) {
                                    TextView avatarTextView = actionView.findViewById(R.id.avatar_text);
                                    if (name != null && !name.isEmpty()) {
                                        String[] names = name.split(" ");
                                        String initials = "";
                                        if (names.length > 0) initials += names[0].charAt(0);
                                        if (names.length > 1) initials += names[names.length - 1].charAt(0);
                                        avatarTextView.setText(initials.toUpperCase());
                                    }
                                    actionView.setOnClickListener(v -> onOptionsItemSelected(profileItem));
                                }
                            }
                        }
                    });
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        int itemId = item.getItemId();
        if (itemId == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupBottomNavigation() {
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        navController = new CustomBottomNavController(this, bottomNav);
        
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection - scroll to top or refresh
                if (itemId == CustomBottomNavController.NAV_HOME) {
                    // Refresh dashboard data
                    setupDashboardDataListener();
                }
            }
        });
        
        // Set current item to home
        navController.setCurrentItem(CustomBottomNavController.NAV_HOME);
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_MESSAGES, 3);
        navController.showBadge(CustomBottomNavController.NAV_TASKS, 5);
        
        // Animate entry
        navController.animateEntry();
    }
    
    private void handleNavigation(int itemId) {
        Intent intent = null;
        
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                // Already in DashboardActivity - just refresh
                setupDashboardDataListener();
                return;
                
            case CustomBottomNavController.NAV_PROJECTS:
                intent = new Intent(getApplicationContext(), ProjectsActivity.class);
                break;
                
            case CustomBottomNavController.NAV_TASKS:
                intent = new Intent(getApplicationContext(), MyTasksActivity.class);
                break;
                
            case CustomBottomNavController.NAV_MESSAGES:
                intent = new Intent(getApplicationContext(), MessagesActivity.class);
                break;
                
            case CustomBottomNavController.NAV_CALENDAR:
                intent = new Intent(getApplicationContext(), CalendarActivity.class);
                break;
        }
        
        if (intent != null) {
            startActivity(intent);
            finish();
        }
    }

    private ColorStateList createColorStateList(int selectedColor, int unselectedColor) {
        int[][] states = new int[][] {
            new int[] { android.R.attr.state_checked }, // selected
            new int[] { -android.R.attr.state_checked }  // unselected
        };
        int[] colors = new int[] {
            selectedColor,
            unselectedColor
        };
        return new ColorStateList(states, colors);
    }

    @Override
    public void onLogout() {
        logoutUser();
    }

    @Override
    public void onProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onActivityLog() {
        startActivity(new Intent(this, GlobalLogActivity.class));
    }

    @Override
    public void onSettings() {
        Toast.makeText(this, "Settings screen coming soon!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }
}