package com.example.teampulse;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.List;

public class KanbanPagerAdapter extends FragmentStateAdapter {

    private final List<Task> planningTasks;
    private final List<Task> inProgressTasks;
    private final List<Task> forReviewTasks;
    private final List<Task> doneTasks;
    private final String projectId;
    private final String currentUserRole;

    public KanbanPagerAdapter(@NonNull FragmentActivity fragmentActivity,
                              List<Task> planningTasks,
                              List<Task> inProgressTasks,
                              List<Task> forReviewTasks,
                              List<Task> doneTasks,
                              String projectId,
                              String currentUserRole) { // ✅ LISTENER REMOVED FROM CONSTRUCTOR
        super(fragmentActivity);
        this.planningTasks = planningTasks;
        this.inProgressTasks = inProgressTasks;
        this.forReviewTasks = forReviewTasks;
        this.doneTasks = doneTasks;
        this.projectId = projectId;
        this.currentUserRole = currentUserRole;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                // ✅ CALLING THE CORRECT newInstance
                return KanbanColumnFragment.newInstance(planningTasks, projectId, currentUserRole);
            case 1:
                return KanbanColumnFragment.newInstance(inProgressTasks, projectId, currentUserRole);
            case 2:
                return KanbanColumnFragment.newInstance(forReviewTasks, projectId, currentUserRole);
            case 3:
                return KanbanColumnFragment.newInstance(doneTasks, projectId, currentUserRole);
            default:
                return new Fragment();
        }
    }

    @Override
    public int getItemCount() {
        return 4;
    }
}