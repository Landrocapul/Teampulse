package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ListItemCalendarTaskBinding;
import com.example.teampulse.databinding.ListItemProjectHeaderBinding;

import java.util.List;

public class CalendarTaskItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_TASK = 1;
    private static final int TYPE_PROJECT_DEADLINE = 2;

    private final List<MyTasksListItem> items;
    private final Context context;

    public CalendarTaskItemAdapter(List<MyTasksListItem> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @Override
    public int getItemViewType(int position) {
        if (items.get(position) instanceof ProjectHeaderItem) {
            return TYPE_HEADER;
        } else if (items.get(position) instanceof ProjectDeadlineItem) {
            return TYPE_PROJECT_DEADLINE;
        } else {
            return TYPE_TASK;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            ListItemProjectHeaderBinding binding = ListItemProjectHeaderBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new ProjectHeaderViewHolder(binding);
        } else if (viewType == TYPE_PROJECT_DEADLINE) {
            ListItemProjectHeaderBinding binding = ListItemProjectHeaderBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new ProjectDeadlineViewHolder(binding);
        } else {
            ListItemCalendarTaskBinding binding = ListItemCalendarTaskBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new TaskViewHolder(binding);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() == TYPE_HEADER) {
            ProjectHeaderItem headerItem = (ProjectHeaderItem) items.get(position);
            ((ProjectHeaderViewHolder) holder).bind(headerItem);
        } else if (holder.getItemViewType() == TYPE_PROJECT_DEADLINE) {
            ProjectDeadlineItem deadlineItem = (ProjectDeadlineItem) items.get(position);
            ((ProjectDeadlineViewHolder) holder).bind(deadlineItem);
        } else {
            TaskItem taskItem = (TaskItem) items.get(position);
            ((TaskViewHolder) holder).bind(taskItem);

            // Add staggered entrance animation for task cards only
            animateItemEntrance(holder.itemView, position);
        }
    }

    private void animateItemEntrance(View itemView, int position) {
        // Clear any existing animations
        itemView.clearAnimation();

        // Calculate delay based on position (50ms per item, max 500ms delay)
        long delay = Math.min(position * 50L, 500L);

        // Set initial state: start from slightly below and fully transparent
        itemView.setAlpha(0f);
        itemView.setTranslationY(30f); // Small upward float from 30px below

        // Animate fade-in while floating up to position
        itemView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(500) // Slightly longer for smoother fade
                .setStartDelay(delay)
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .start();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // ViewHolder for Project Headers
    static class ProjectHeaderViewHolder extends RecyclerView.ViewHolder {
        private final ListItemProjectHeaderBinding binding;
        ProjectHeaderViewHolder(ListItemProjectHeaderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
        void bind(ProjectHeaderItem headerItem) {
            binding.tvProjectTitle.setText(headerItem.getProjectTitle());
        }
    }

    // ViewHolder for Task Items
    class TaskViewHolder extends RecyclerView.ViewHolder {
        private final ListItemCalendarTaskBinding binding;
        TaskViewHolder(ListItemCalendarTaskBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            // Add click animation feedback
            setupClickAnimation();
        }

        private void setupClickAnimation() {
            itemView.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        animateScale(v, 0.95f);
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        animateScale(v, 1.0f);
                        break;
                }
                return false; // Don't consume the event
            });
        }

        private void animateScale(View view, float scale) {
            view.animate()
                    .scaleX(scale)
                    .scaleY(scale)
                    .setDuration(100)
                    .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                    .start();
        }

        void bind(TaskItem taskItem) {
            Task task = taskItem.getTask();
            binding.tvTaskTitle.setText(task.getTitle());

            // Set assignee text
            String assigneeName = task.getAssigneeName();
            if (assigneeName != null && !assigneeName.isEmpty()) {
                binding.tvTaskAssignee.setText("Assigned to: " + assigneeName);
                binding.tvTaskAssignee.setVisibility(View.VISIBLE);
            } else {
                binding.tvTaskAssignee.setVisibility(View.GONE);
            }

            // Set status icon and color based on task status
            int iconRes = R.drawable.ic_status_planning;
            int colorRes = R.color.yellow;
            String statusText = "PLANNING";

            switch(task.getStatusEnum()) {
                case DONE:
                    iconRes = R.drawable.ic_status_done;
                    colorRes = R.color.done_green;
                    statusText = "DONE";
                    break;
                case PLANNING:
                    iconRes = R.drawable.ic_status_planning;
                    colorRes = R.color.yellow;
                    statusText = "PLANNING";
                    break;
                case ONGOING:
                    iconRes = R.drawable.ic_status_in_progress;
                    colorRes = R.color.inprogress_orange;
                    statusText = "Ongoing";
                    break;
                case FOR_REVIEW:
                    iconRes = R.drawable.ic_status_review;
                    colorRes = R.color.blue;
                    statusText = "TO REVIEW";
                    break;
                case TO_REVIEW:
                    iconRes = R.drawable.ic_status_review;
                    colorRes = R.color.blue;
                    statusText = "TO REVIEW";
                    break;
            }

            binding.chipTaskStatus.setChipIconResource(iconRes);
            binding.chipTaskStatus.setText(statusText);
            binding.chipTaskStatus.setChipBackgroundColorResource(colorRes);

            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, ProjectDetailsActivity.class);
                intent.putExtra("PROJECT_ID", task.getProjectId());
                context.startActivity(intent);
            });
        }
    }

    // ViewHolder for Project Deadline Items
    static class ProjectDeadlineViewHolder extends RecyclerView.ViewHolder {
        private final ListItemProjectHeaderBinding binding;
        ProjectDeadlineViewHolder(ListItemProjectHeaderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
        void bind(ProjectDeadlineItem deadlineItem) {
            Project project = deadlineItem.getProject();
            String deadlineText = "📅 " + project.getTitle() + " - Deadline";
            binding.tvProjectTitle.setText(deadlineText);
            binding.getRoot().setOnClickListener(v -> {
                Intent intent = new Intent(binding.getRoot().getContext(), ProjectDetailsActivity.class);
                intent.putExtra("PROJECT_ID", project.getId());
                binding.getRoot().getContext().startActivity(intent);
            });
        }
    }
}
