// Project.java (Updated)
package com.example.teampulse;

import java.io.Serializable;
import java.util.List;

public class Project implements Serializable {

    private String id; // Firestore document ID
    private String title;
    private String description;
    private String leaderId;
    private String leaderName;
    private String createdDate;
    private String deadline;
    private String joinCode;
    private String teacherCode;
    private double progress;
    private int totalPoints;
    private String teacherId;
    private List<String> teamMembers; // To store UIDs of all members

    public Project() {} // Empty constructor required by Firestore

    public String getTeacherId() { return teacherId; }
    public void setTeacherId(String teacherId) { this.teacherId = teacherId; }

    // --- Getters and Setters ---
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public int getTotalPoints() { return totalPoints; }
    public void setTotalPoints(int totalPoints) { this.totalPoints = totalPoints; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getLeaderId() { return leaderId; }
    public void setLeaderId(String leaderId) { this.leaderId = leaderId; }

    public String getLeaderName() { return leaderName; }
    public void setLeaderName(String leaderName) { this.leaderName = leaderName; }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }

    public String getJoinCode() { return joinCode; }
    public void setJoinCode(String joinCode) { this.joinCode = joinCode; }

    public String getTeacherCode() { return teacherCode; }
    public void setTeacherCode(String teacherCode) { this.teacherCode = teacherCode; }

    public double getProgress() { return progress; }
    public void setProgress(double progress) { this.progress = progress; }

    // Getter and Setter for teamMembers
    public List<String> getTeamMembers() { return teamMembers; }
    public void setTeamMembers(List<String> teamMembers) { this.teamMembers = teamMembers; }
}