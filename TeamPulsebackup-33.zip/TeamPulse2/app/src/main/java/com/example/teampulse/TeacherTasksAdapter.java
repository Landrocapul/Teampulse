package com.example.teampulse;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ItemTaskCardBinding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherTasksAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_TASK = 1;

    private Context context;
    private List<Object> items; // Can be Task or ProjectHeader
    private Map<String, Project> projectMap;

    public TeacherTasksAdapter(Context context, List<Task> tasks) {
        this.context = context;
        this.projectMap = new HashMap<>();
        setTasks(tasks);
    }

    public void setTasks(List<Task> tasks) {
        this.items = new ArrayList<>();
        if (tasks != null) {
            // Group tasks by project
            Map<String, List<Task>> tasksByProject = new HashMap<>();
            for (Task task : tasks) {
                String projectId = task.getProjectId();
                if (!tasksByProject.containsKey(projectId)) {
                    tasksByProject.put(projectId, new ArrayList<>());
                }
                tasksByProject.get(projectId).add(task);
            }

            // Sort tasks within each project by due date
            for (List<Task> projectTasks : tasksByProject.values()) {
                Collections.sort(projectTasks, new Comparator<Task>() {
                    @Override
                    public int compare(Task t1, Task t2) {
                        if (t1.getDueDate() == null && t2.getDueDate() == null) return 0;
                        if (t1.getDueDate() == null) return 1;
                        if (t2.getDueDate() == null) return -1;
                        return t1.getDueDate().compareTo(t2.getDueDate());
                    }
                });
            }

            // Create items list with headers and tasks
            for (Map.Entry<String, List<Task>> entry : tasksByProject.entrySet()) {
                String projectId = entry.getKey();
                List<Task> projectTasks = entry.getValue();

                // Add project header
                Project project = projectMap.get(projectId);
                String projectName = (project != null) ? project.getTitle() : "Unknown Project";
                this.items.add(new ProjectHeader(projectName, projectTasks.size()));

                // Add tasks for this project
                this.items.addAll(projectTasks);
            }
        }
        notifyDataSetChanged();
    }

    public void setProjectMap(Map<String, Project> projectMap) {
        this.projectMap = projectMap;
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) instanceof ProjectHeader ? TYPE_HEADER : TYPE_TASK;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_HEADER) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_project_header, parent, false);
            return new ProjectHeaderViewHolder(view);
        } else {
            ItemTaskCardBinding binding = ItemTaskCardBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new TaskViewHolder(binding);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position) == TYPE_HEADER) {
            ProjectHeader header = (ProjectHeader) items.get(position);
            ((ProjectHeaderViewHolder) holder).bind(header);

            // Add staggered entrance animation for project headers
            animateItemEntrance(holder.itemView, position);
        } else {
            Task task = (Task) items.get(position);
            ((TaskViewHolder) holder).bind(task);

            // Add staggered entrance animation for task cards only
            animateItemEntrance(holder.itemView, position);
        }
    }

    @Override
    public int getItemCount() {
        return items != null ? items.size() : 0;
    }

    private void animateItemEntrance(View itemView, int position) {
        // Clear any existing animations
        itemView.clearAnimation();

        // Calculate delay based on position (50ms per item, max 500ms delay)
        long delay = Math.min(position * 50L, 500L);

        // Set initial state: start from slightly below and fully transparent
        itemView.setAlpha(0f);
        itemView.setTranslationY(30f); // Small upward float from 30px below

        // Animate fade-in while floating up to position
        itemView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(500) // Slightly longer for smoother fade
                .setStartDelay(delay)
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .start();
    }

    static class ProjectHeaderViewHolder extends RecyclerView.ViewHolder {
        private TextView tvProjectName;
        private TextView tvTaskCount;

        public ProjectHeaderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProjectName = itemView.findViewById(R.id.tv_project_name);
            tvTaskCount = itemView.findViewById(R.id.tv_task_count);

            // Add click animation feedback
            setupClickAnimation();
        }

        public void bind(ProjectHeader header) {
            tvProjectName.setText(header.projectName);
            tvTaskCount.setText(header.taskCount + " tasks");
        }

        private void setupClickAnimation() {
            itemView.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        animateScale(v, 0.95f);
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        animateScale(v, 1.0f);
                        break;
                }
                return false; // Don't consume the event
            });
        }

        private void animateScale(View view, float scale) {
            view.animate()
                    .scaleX(scale)
                    .scaleY(scale)
                    .setDuration(100)
                    .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                    .start();
        }
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        private ItemTaskCardBinding binding;

        public TaskViewHolder(ItemTaskCardBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            // Add click animation feedback
            setupClickAnimation();
        }

        public void bind(Task task) {
            binding.tvTitle.setText(task.getTitle());
            binding.tvAssignee.setText("Assigned to: " + task.getAssigneeName());
            binding.tvDate.setText("Due: " + task.getDueDate());
            
            // Hide the change status button for teacher tasks
            binding.btnChangeStatus.setVisibility(View.GONE);
            
            // Note: Status and priority can be added later if chips are added to layout
            // For now, just display basic task information
        }

        private void setupClickAnimation() {
            itemView.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        animateScale(v, 0.95f);
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        animateScale(v, 1.0f);
                        break;
                }
                return false; // Don't consume the event
            });
        }

        private void animateScale(View view, float scale) {
            view.animate()
                    .scaleX(scale)
                    .scaleY(scale)
                    .setDuration(100)
                    .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                    .start();
        }

        private int getStatusColor(Context context, String status) {
            switch (status) {
                case "DONE":
                    return context.getResources().getColor(android.R.color.holo_green_dark);
                case "ONGOING":
                    return context.getResources().getColor(android.R.color.holo_blue_dark);
                case "PLANNING":
                    return context.getResources().getColor(android.R.color.holo_orange_dark);
                case "TO_REVIEW":
                case "FOR_REVIEW":
                    return context.getResources().getColor(android.R.color.holo_blue_bright);
                default:
                    return context.getResources().getColor(android.R.color.darker_gray);
            }
        }

        private int getDifficultyColor(Context context, int difficulty) {
            switch (difficulty) {
                case 3:
                    return context.getResources().getColor(android.R.color.holo_red_dark);
                case 2:
                    return context.getResources().getColor(android.R.color.holo_orange_dark);
                case 1:
                    return context.getResources().getColor(android.R.color.holo_green_dark);
                default:
                    return context.getResources().getColor(android.R.color.darker_gray);
            }
        }
    }

    // Helper class for project headers
    public static class ProjectHeader {
        public String projectName;
        public int taskCount;

        public ProjectHeader(String projectName, int taskCount) {
            this.projectName = projectName;
            this.taskCount = taskCount;
        }
    }
}
