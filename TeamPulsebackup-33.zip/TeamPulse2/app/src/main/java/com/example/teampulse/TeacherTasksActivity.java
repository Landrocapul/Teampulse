package com.example.teampulse;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.tabs.TabLayoutMediator;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TeacherTasksActivity extends AppCompatActivity implements NavigationDrawerFragment.NavigationListener, NavigationDrawerFragment.DrawerActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private Map<String, String> projectIdToTitleMap = new HashMap<>();
    private String currentUserRole = "";

    // Drawer components
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;
    private CustomBottomNavController navController;
    
    // View components
    private androidx.swiperefreshlayout.widget.SwipeRefreshLayout swipeRefreshLayout;
    private androidx.viewpager2.widget.ViewPager2 viewPager;
    private com.google.android.material.tabs.TabLayout tabLayout;
    private androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_tasks);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setupSwipeRefresh();
        setupViews();
        loadProjectMapAndUserData();
        setupToolbarAndDrawer();
        setupBottomNavigation();
    }

    // NEW method to initialize drawer views
    private void setupViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
        toolbar = findViewById(R.id.toolbar);
        viewPager = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);
        
        // Debug logging
        android.util.Log.d("TeacherTasks", "Views initialized:");
        android.util.Log.d("TeacherTasks", "drawerLayout: " + (drawerLayout != null ? "OK" : "NULL"));
        android.util.Log.d("TeacherTasks", "toolbar: " + (toolbar != null ? "OK" : "NULL"));
        android.util.Log.d("TeacherTasks", "viewPager: " + (viewPager != null ? "OK" : "NULL"));
        android.util.Log.d("TeacherTasks", "tabLayout: " + (tabLayout != null ? "OK" : "NULL"));
        android.util.Log.d("TeacherTasks", "swipeRefreshLayout: " + (swipeRefreshLayout != null ? "OK" : "NULL"));
    }

    // NEW method to set up the drawer
    private void setupToolbarAndDrawer() {
        setSupportActionBar(toolbar);
        toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Setup navigation drawer fragment
        NavigationDrawerFragment drawerFragment = new NavigationDrawerFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.drawer_fragment_container, drawerFragment)
                .commit();
    }

    private void setupSwipeRefresh() {
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setOnRefreshListener(() -> {
                loadProjectMapAndUserData();
            });
        }
    }

    private void loadProjectMapAndUserData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        // Load user role
        db.collection("users").document(currentUser.getUid())
                .get()
                .addOnSuccessListener(userDoc -> {
                    if (userDoc.exists()) {
                        currentUserRole = userDoc.getString("role");
                        // Load all projects where this teacher is the teacher
                        loadAllStudentTasks();
                    }
                });
    }

    private void loadAllStudentTasks() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        android.util.Log.d("TeacherTasks", "Loading all student tasks for teacher: " + currentUser.getUid());

        // Load all projects where this teacher is the teacher
        db.collection("projects")
                .whereEqualTo("teacherId", currentUser.getUid())
                .get()
                .addOnSuccessListener(projectQuery -> {
                    android.util.Log.d("TeacherTasks", "Found " + projectQuery.size() + " projects for teacher");
                    projectIdToTitleMap.clear();
                    List<String> projectIds = new ArrayList<>();

                    for (com.google.firebase.firestore.DocumentSnapshot doc : projectQuery.getDocuments()) {
                        projectIds.add(doc.getId());
                        projectIdToTitleMap.put(doc.getId(), doc.getString("title"));
                        android.util.Log.d("TeacherTasks", "Project: " + doc.getId() + " - " + doc.getString("title"));
                    }

                    if (projectIds.isEmpty()) {
                        android.util.Log.d("TeacherTasks", "No projects found, showing empty tabs");
                        setupViewPagerAndTabs(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
                        return;
                    }

                    // Load all tasks from all projects
                    loadTasksFromProjects(projectIds);
                })
                .addOnFailureListener(e -> {
                    android.util.Log.e("TeacherTasks", "Error loading projects: " + e.getMessage());
                    setupViewPagerAndTabs(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
                });
    }

    private void loadTasksFromProjects(List<String> projectIds) {
        List<com.example.teampulse.Task> allTasks = new ArrayList<>();
        java.util.concurrent.atomic.AtomicInteger completedQueries = new java.util.concurrent.atomic.AtomicInteger(0);
        final int totalQueries = projectIds.size();

        android.util.Log.d("TeacherTasks", "Loading tasks from " + totalQueries + " projects");

        // Load tasks from each project
        for (String projectId : projectIds) {
            db.collection("projects")
                    .document(projectId)
                    .collection("tasks")
                    .get()
                    .addOnSuccessListener(taskQuery -> {
                        android.util.Log.d("TeacherTasks", "Loaded " + taskQuery.size() + " tasks from project " + projectId);
                        
                        for (com.google.firebase.firestore.DocumentSnapshot doc : taskQuery.getDocuments()) {
                            com.example.teampulse.Task task = doc.toObject(com.example.teampulse.Task.class);
                            if (task != null) {
                                task.setId(doc.getId());
                                task.setProjectId(projectId);
                                allTasks.add(task);
                                android.util.Log.d("TeacherTasks", "Task: " + task.getTitle() + " - " + task.getStatus());
                            }
                        }

                        // Check if all projects are loaded
                        int completed = completedQueries.incrementAndGet();
                        android.util.Log.d("TeacherTasks", "Completed " + completed + "/" + totalQueries + " project queries");
                        
                        if (completed == totalQueries) {
                            android.util.Log.d("TeacherTasks", "All projects loaded, processing " + allTasks.size() + " total tasks");
                            processAndDisplayTasks(allTasks);
                        }
                    })
                    .addOnFailureListener(e -> {
                        android.util.Log.e("TeacherTasks", "Error loading tasks from project " + projectId + ": " + e.getMessage());
                        
                        // Still count as completed even on failure
                        int completed = completedQueries.incrementAndGet();
                        if (completed == totalQueries) {
                            android.util.Log.d("TeacherTasks", "All queries completed (with errors), processing " + allTasks.size() + " tasks");
                            processAndDisplayTasks(allTasks);
                        }
                    });
        }
    }

    private void processAndDisplayTasks(List<com.example.teampulse.Task> allTasks) {
        android.util.Log.d("TeacherTasks", "Processing and displaying " + allTasks.size() + " tasks");
        
        // Filter tasks by status (teacher sees all student tasks)
        List<com.example.teampulse.Task> planningTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == com.example.teampulse.TaskStatus.PLANNING)
                .collect(Collectors.toList());

        List<com.example.teampulse.Task> ongoingTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == com.example.teampulse.TaskStatus.ONGOING)
                .collect(Collectors.toList());

        List<com.example.teampulse.Task> reviewTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == com.example.teampulse.TaskStatus.FOR_REVIEW)
                .collect(Collectors.toList());

        List<com.example.teampulse.Task> completedTasks = allTasks.stream()
                .filter(t -> t.getStatusEnum() == com.example.teampulse.TaskStatus.DONE)
                .collect(Collectors.toList());

        android.util.Log.d("TeacherTasks", "Task breakdown - Planning: " + planningTasks.size() + ", Ongoing: " + ongoingTasks.size() + ", Review: " + reviewTasks.size() + ", Done: " + completedTasks.size());

        setupViewPagerAndTabs(planningTasks, ongoingTasks, reviewTasks, completedTasks);

        // Stop the refreshing animation
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    private void setupViewPagerAndTabs(List<com.example.teampulse.Task> planning, List<com.example.teampulse.Task> ongoing, List<com.example.teampulse.Task> review, List<com.example.teampulse.Task> completed) {
        android.util.Log.d("TeacherTasks", "Setting up ViewPager and tabs");
        android.util.Log.d("TeacherTasks", "Planning: " + planning.size() + ", Ongoing: " + ongoing.size() + ", Review: " + review.size() + ", Done: " + completed.size());
        
        if (viewPager == null || tabLayout == null) {
            android.util.Log.e("TeacherTasks", "ViewPager or TabLayout is null - cannot setup");
            return;
        }
        
        MyTasksPagerAdapter pagerAdapter = new MyTasksPagerAdapter(this, planning, ongoing, review, completed, projectIdToTitleMap);
        viewPager.setAdapter(pagerAdapter);
        android.util.Log.d("TeacherTasks", "PagerAdapter set with " + pagerAdapter.getItemCount() + " tabs");

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            switch (position) {
                case 0:
                    tab.setText("Planning (" + planning.size() + ")");
                    break;
                case 1:
                    tab.setText("Ongoing (" + ongoing.size() + ")");
                    break;
                case 2:
                    tab.setText("Review (" + review.size() + ")");
                    break;
                case 3:
                    tab.setText("Done (" + completed.size() + ")");
                    break;
            }
            android.util.Log.d("TeacherTasks", "Tab " + position + " set: " + tab.getText());
        }).attach();
        
        android.util.Log.d("TeacherTasks", "ViewPager and tabs setup complete");
    }

    private void setupBottomNavigation() {
        ConstraintLayout bottomNav = findViewById(R.id.custom_bottom_nav);
        navController = new CustomBottomNavController(this, bottomNav);
        
        // Set current item to tasks BEFORE setting the listener to avoid triggering navigation
        navController.setCurrentItem(CustomBottomNavController.NAV_TASKS);
        
        // Set up navigation listener
        navController.setOnNavigationListener(new CustomBottomNavController.OnNavigationListener() {
            @Override
            public void onNavigationItemSelected(int itemId) {
                handleNavigation(itemId);
            }
            
            @Override
            public void onNavigationItemReselected(int itemId) {
                // Handle reselection - refresh tasks
                if (itemId == CustomBottomNavController.NAV_TASKS) {
                    // Refresh tasks data
                    loadProjectMapAndUserData();
                }
            }
        });
        
        // Show sample badges
        navController.showBadge(CustomBottomNavController.NAV_MESSAGES, 1);
        navController.showBadge(CustomBottomNavController.NAV_PROJECTS, 2);
        
        // Animate entry (disabled)
        navController.animateEntry();
    }
    
    private void handleNavigation(int itemId) {
        Intent intent = null;
        
        android.util.Log.d("TeacherTasks", "Navigation selected: " + itemId);
        
        switch (itemId) {
            case CustomBottomNavController.NAV_HOME:
                android.util.Log.d("TeacherTasks", "Navigating to TeacherDashboardActivity");
                intent = new Intent(this, TeacherDashboardActivity.class);
                break;
                
            case CustomBottomNavController.NAV_PROJECTS:
                android.util.Log.d("TeacherTasks", "Navigating to TeacherProjectsActivity");
                intent = new Intent(this, TeacherProjectsActivity.class);
                break;
                
            case CustomBottomNavController.NAV_TASKS:
                android.util.Log.d("TeacherTasks", "Already in TeacherTasksActivity - refreshing");
                // Already in TeacherTasksActivity - just refresh
                loadProjectMapAndUserData();
                return;
                
            case CustomBottomNavController.NAV_MESSAGES:
                android.util.Log.d("TeacherTasks", "Navigating to MessagesActivity");
                intent = new Intent(this, MessagesActivity.class);
                break;
                
            case CustomBottomNavController.NAV_CALENDAR:
                android.util.Log.d("TeacherTasks", "Navigating to CalendarActivity");
                intent = new Intent(this, CalendarActivity.class);
                break;
        }
        
        if (intent != null) {
            android.util.Log.d("TeacherTasks", "Starting intent: " + intent.getComponent().getClassName());
            startActivity(intent);
            finish();
        } else {
            android.util.Log.e("TeacherTasks", "Intent was null for itemId: " + itemId);
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onLogout() {
        logoutUser();
    }

    @Override
    public void onProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onSettings() {
        // Navigate to profile activity as settings alternative
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onActivityLog() {
        // Navigate to activity log activity
        startActivity(new Intent(this, ActivityLogActivity.class));
    }

    @Override
    public void closeDrawer() {
        if (drawerLayout != null) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    private void logoutUser() {
        mAuth.signOut();
        startActivity(new Intent(this, SignInActivity.class));
        finish();
    }
}
