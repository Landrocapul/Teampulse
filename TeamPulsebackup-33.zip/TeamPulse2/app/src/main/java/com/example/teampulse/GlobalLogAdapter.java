package com.example.teampulse;

import android.content.Context;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.example.teampulse.ActivityLog.EventType;
import java.util.List;
import java.util.Map;

public class GlobalLogAdapter extends RecyclerView.Adapter<GlobalLogAdapter.GlobalLogViewHolder> {

    private final List<ActivityLog> logList;
    private final Map<String, String> projectIdToTitleMap; // Map to get project titles
    private final Context context;

    public GlobalLogAdapter(Context context, List<ActivityLog> logList, Map<String, String> projectIdToTitleMap) {
        this.context = context;
        this.logList = logList;
        this.projectIdToTitleMap = projectIdToTitleMap;
    }

    @NonNull
    @Override
    public GlobalLogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.log_item_global, parent, false);
        return new GlobalLogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GlobalLogViewHolder holder, int position) {
        ActivityLog log = logList.get(position);

        // Find the project ID associated with this log. We need to add this to the ActivityLog model.
        String projectId = log.getProjectId();
        String projectTitle = projectIdToTitleMap.get(projectId);

        holder.bind(log, projectTitle);
    }

    @Override
    public int getItemCount() {
        return logList.size();
    }

    static class GlobalLogViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvProjectName;
        private final TextView tvMessage;
        private final TextView tvTimestamp;
        private final ImageView ivIcon;

        public GlobalLogViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProjectName = itemView.findViewById(R.id.tv_project_name);
            tvMessage = itemView.findViewById(R.id.tv_log_message);
            tvTimestamp = itemView.findViewById(R.id.tv_log_timestamp);
            ivIcon = itemView.findViewById(R.id.log_icon);
        }

        public void bind(ActivityLog log, String projectTitle) {
            if (projectTitle != null) {
                tvProjectName.setText("IN PROJECT: " + projectTitle.toUpperCase());
                tvProjectName.setVisibility(View.VISIBLE);
            } else {
                tvProjectName.setVisibility(View.GONE);
            }

            String fullMessage = "<b>" + log.getAuthorName() + "</b> " + log.getLogMessage();
            tvMessage.setText(android.text.Html.fromHtml(fullMessage));

            if (log.getTimestamp() != null) {
                CharSequence timeAgo = DateUtils.getRelativeTimeSpanString(log.getTimestamp().getTime(),
                        System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS);
                tvTimestamp.setText(timeAgo);
            }

            // Set icon based on event type
            EventType type = log.getEventType();
            if (type == EventType.PROJECT_CREATED || type == EventType.TASK_CREATED) {
                ivIcon.setImageResource(android.R.drawable.ic_input_add);
                ivIcon.setColorFilter(ContextCompat.getColor(itemView.getContext(), R.color.done_green));
            } else {
                ivIcon.setColorFilter(ContextCompat.getColor(itemView.getContext(), R.color.gray)); // Reset tint
                switch (type) {
                    case TASK_STATUS_CHANGED: ivIcon.setImageResource(R.drawable.ic_edit); break;
                    case MEMBER_JOINED: ivIcon.setImageResource(R.drawable.ic_uncomplete); break;
                    case TASK_DELETED: ivIcon.setImageResource(R.drawable.ic_delete); break;
                    default: ivIcon.setImageResource(R.drawable.ic_more_vert);
                }
            }
        }
    }
}