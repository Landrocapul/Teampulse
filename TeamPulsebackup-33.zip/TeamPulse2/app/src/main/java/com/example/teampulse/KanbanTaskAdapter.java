package com.example.teampulse;

import android.content.Context;
import android.content.Intent;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.teampulse.databinding.ItemTaskCardBinding;
import com.google.android.material.chip.Chip;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class KanbanTaskAdapter extends RecyclerView.Adapter<KanbanTaskAdapter.TaskViewHolder> {

    private final List<Task> taskList;
    private final String projectId;
    private final String currentUserRole;
    private final OnTaskUpdatedListener listener;

    public KanbanTaskAdapter(List<Task> taskList, String projectId, String currentUserRole, OnTaskUpdatedListener listener) {
        this.taskList = taskList;
        this.projectId = projectId;
        this.currentUserRole = currentUserRole;
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemTaskCardBinding binding = ItemTaskCardBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new TaskViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.bind(task, projectId, currentUserRole, listener);

        // Add staggered entrance animation
        animateItemEntrance(holder.itemView, position);
    }

    private void animateItemEntrance(View itemView, int position) {
        // Clear any existing animations
        itemView.clearAnimation();

        // Calculate delay based on position (50ms per item, max 500ms delay)
        long delay = Math.min(position * 50L, 500L);

        // Set initial state: start from slightly below and fully transparent
        itemView.setAlpha(0f);
        itemView.setTranslationY(30f); // Small upward float from 30px below

        // Animate fade-in while floating up to position
        itemView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(500) // Slightly longer for smoother fade
                .setStartDelay(delay)
                .setInterpolator(new android.view.animation.DecelerateInterpolator())
                .start();
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {
        private final ItemTaskCardBinding binding;

        public TaskViewHolder(ItemTaskCardBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            // Add click animation feedback
            setupClickAnimation();
        }

        private void setupClickAnimation() {
            itemView.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        animateScale(v, 0.95f);
                        break;
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL:
                        animateScale(v, 1.0f);
                        break;
                }
                return false; // Don't consume the event
            });
        }

        private void animateScale(View view, float scale) {
            view.animate()
                    .scaleX(scale)
                    .scaleY(scale)
                    .setDuration(100)
                    .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator())
                    .start();
        }

        public void bind(Task task, String projectId, String userRole, OnTaskUpdatedListener listener) {
            binding.tvTitle.setText(task.getTitle());
            binding.tvAssignee.setText("Assigned: " + task.getAssigneeName());
            binding.tvDate.setText("Due: " + task.getDueDate());

            binding.chipGroup.removeAllViews();
            Context context = itemView.getContext();

            if (task.getType() != null && !task.getType().isEmpty()) {
                Chip typeChip = new Chip(context);
                typeChip.setText(task.getType());
                binding.chipGroup.addView(typeChip);
            }

            Chip pointsChip = new Chip(context);
            pointsChip.setText(task.getPoints() + " Points");
            binding.chipGroup.addView(pointsChip);

            int pointsColorRes;
            switch (task.getPoints()) {
                case 1: case 2: pointsColorRes = R.color.done_green; break;
                case 3: case 5: pointsColorRes = R.color.yellow; break;
                case 8: case 13: default: pointsColorRes = R.color.red_primary; break;
            }
            pointsChip.setChipBackgroundColorResource(pointsColorRes);
            pointsChip.setTextColor(ContextCompat.getColor(context, R.color.white));

            // ✅ Set up the click listener for the new "info" button
            binding.btnTaskInfo.setOnClickListener(v -> showTaskDetailsDialog(task, context));

            if (task.getStatusEnum() == TaskStatus.FOR_REVIEW && task.getCompletionNote() != null) {
                binding.divider.setVisibility(View.VISIBLE);
                binding.tvCompletionNoteLabel.setVisibility(View.VISIBLE);
                binding.tvCompletionNote.setVisibility(View.VISIBLE);
                binding.tvCompletionNote.setText(task.getCompletionNote());
            } else {
                binding.divider.setVisibility(View.GONE);
                binding.tvCompletionNoteLabel.setVisibility(View.GONE);
                binding.tvCompletionNote.setVisibility(View.GONE);
            }

            binding.btnChangeStatus.setOnClickListener(v -> {
                if ("Leader".equals(userRole)) {
                    showLeaderActionDialog(task, projectId, listener, v.getContext());
                } else {
                    showMemberActionDialog(task, projectId, listener, v.getContext());
                }
            });

            if (!"Leader".equals(userRole) && task.getStatusEnum() == TaskStatus.ONGOING) {
                binding.btnChangeStatus.setText("Submit for Review");
            } else {
                binding.btnChangeStatus.setText("Change Status");
            }

            if ("Leader".equals(userRole)) {
                binding.btnTaskInfo.setVisibility(View.GONE); // Hide 3-dots if edit/delete are visible
                binding.btnEditTask.setVisibility(View.VISIBLE);
                binding.btnDeleteTask.setVisibility(View.VISIBLE);
                binding.btnEditTask.setOnClickListener(v -> {
                    Intent intent = new Intent(v.getContext(), CreateTaskActivity.class);
                    intent.putExtra("PROJECT_ID", projectId);
                    intent.putExtra("EDIT_TASK_ID", task.getId());
                    v.getContext().startActivity(intent);
                });
                binding.btnDeleteTask.setOnClickListener(v -> {
                    new AlertDialog.Builder(v.getContext())
                            .setTitle("Delete Task")
                            .setMessage("Are you sure you want to delete this task? This action cannot be undone.")
                            .setPositiveButton("Delete", (dialog, which) -> deleteTask(task, projectId, listener, v.getContext()))
                            .setNegativeButton("Cancel", null)
                            .show();
                });
            } else {
                binding.btnTaskInfo.setVisibility(View.VISIBLE); // Show 3-dots for non-leaders
                binding.btnEditTask.setVisibility(View.GONE);
                binding.btnDeleteTask.setVisibility(View.GONE);
            }
        }

        // ✅ NEW METHOD to build and show the custom dialog
        private void showTaskDetailsDialog(Task task, Context context) {
            // Inflate the custom layout
            LayoutInflater inflater = LayoutInflater.from(context);
            View dialogView = inflater.inflate(R.layout.dialog_task_details, null);

            // Create the AlertDialog builder
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setView(dialogView);

            // Find views inside the custom layout
            TextView title = dialogView.findViewById(R.id.dialog_task_title);
            TextView description = dialogView.findViewById(R.id.dialog_task_description);
            TextView assignee = dialogView.findViewById(R.id.dialog_assignee);
            TextView dueDate = dialogView.findViewById(R.id.dialog_due_date);
            TextView points = dialogView.findViewById(R.id.dialog_points);
            TextView type = dialogView.findViewById(R.id.dialog_type);
            ImageButton closeButton = dialogView.findViewById(R.id.btn_close_dialog);

            // Populate the views with task data
            title.setText(task.getTitle());
            description.setText(task.getDescription());
            assignee.setText(task.getAssigneeName());
            dueDate.setText(task.getDueDate());
            points.setText(task.getPoints() + " Points");
            type.setText(task.getType());

            // Create and show the dialog
            AlertDialog dialog = builder.create();
            dialog.show();

            // Set the listener for the close button
            closeButton.setOnClickListener(v -> dialog.dismiss());
        }

        private void deleteTask(Task task, String projectId, OnTaskUpdatedListener listener, Context context) {
            FirebaseFirestore.getInstance().collection("projects").document(projectId)
                    .collection("tasks").document(task.getId()).delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(context, "Task deleted.", Toast.LENGTH_SHORT).show();
                        if (listener != null) listener.onTaskUpdated();
                    })
                    .addOnFailureListener(e -> Toast.makeText(context, "Failed to delete task.", Toast.LENGTH_SHORT).show());
        }

        private void showMemberActionDialog(Task task, String projectId, OnTaskUpdatedListener listener, Context context) {
            String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            if (task.getStatusEnum() == TaskStatus.ONGOING && currentUserId.equals(task.getAssigneeUid())) {
                new AlertDialog.Builder(context)
                        .setTitle("Task Action")
                        .setItems(new String[]{"Submit for Review"}, (dialog, which) ->
                                showSubmitReviewDialog(task, projectId, listener, context))
                        .show();
            } else {
                Toast.makeText(context, "No actions available for this task.", Toast.LENGTH_SHORT).show();
            }
        }

        private void showSubmitReviewDialog(Task task, String projectId, OnTaskUpdatedListener listener, Context context) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Submit for Review");
            builder.setMessage("Add a note about what you completed:");
            final EditText input = new EditText(context);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            input.setHint("e.g., Finished the API integration.");
            input.setLines(3);
            builder.setView(input);
            builder.setPositiveButton("Submit", (dialog, which) -> {
                String note = input.getText().toString().trim();
                if (note.isEmpty()) {
                    Toast.makeText(context, "Completion note cannot be empty.", Toast.LENGTH_SHORT).show();
                } else {
                    updateTaskStatus(task, projectId, TaskStatus.FOR_REVIEW, note, "Submitted for review!", listener, context);
                }
            });
            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        }

        private void showLeaderActionDialog(Task task, String projectId, OnTaskUpdatedListener listener, Context context) {
            if (task.getStatusEnum() == TaskStatus.FOR_REVIEW || task.getStatusEnum() == TaskStatus.TO_REVIEW) {
                new AlertDialog.Builder(context)
                        .setTitle("Review Task: " + task.getTitle())
                        .setMessage("Completion Note:\n\"" + task.getCompletionNote() + "\"")
                        .setPositiveButton("Approve", (dialog, which) ->
                                updateTaskStatus(task, projectId, TaskStatus.DONE, null, "Task Approved!", listener, context))
                        .setNegativeButton("Reject", (dialog, which) ->
                                updateTaskStatus(task, projectId, TaskStatus.ONGOING, null, "Task Rejected.", listener, context))
                        .setNeutralButton("Cancel", null)
                        .show();
            } else {
                final String[] statuses = {"Planning", "Ongoing", "To Review", "Done"};
                new AlertDialog.Builder(context)
                        .setTitle("Change Task Status")
                        .setItems(statuses, (dialog, which) -> {
                            TaskStatus newStatus = TaskStatus.valueOf(statuses[which].toUpperCase().replace(" ", "_"));
                            updateTaskStatus(task, projectId, newStatus, null, "Status updated.", listener, context);
                        })
                        .show();
            }
        }

        private void updateTaskStatus(Task task, String projectId, TaskStatus newStatus, @Nullable String note, String toastMessage, OnTaskUpdatedListener listener, Context context) {
            Map<String, Object> updates = new HashMap<>();
            updates.put("status", newStatus.name());
            if (note != null) {
                updates.put("completionNote", note);
            } else if (newStatus == TaskStatus.ONGOING) {
                updates.put("completionNote", FieldValue.delete());
            }
            FirebaseFirestore.getInstance().collection("projects").document(projectId)
                    .collection("tasks").document(task.getId()).update(updates)
                    .addOnSuccessListener(aVoid -> {
                        // ✅ The task status changed! Log it.
                        // We format the status name to be more readable (e.g., "ONGOING" -> "Ongoing")
                        String formattedStatus = newStatus.name().replace('_', ' ').toLowerCase();
                        String logMessage = "changed the status of task '" + task.getTitle() + "' to " + formattedStatus + ".";
                        LogHelper.logActivity(projectId, logMessage, ActivityLog.EventType.TASK_STATUS_CHANGED);

                        Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show();
                        if (listener != null) listener.onTaskUpdated();
                    })
                    .addOnFailureListener(e -> Toast.makeText(context, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }
}