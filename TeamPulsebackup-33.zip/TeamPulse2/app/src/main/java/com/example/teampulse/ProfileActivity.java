package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.teampulse.databinding.ActivityProfileBinding;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private ActivityProfileBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private FirebaseUser currentUser;
    private User currentUserData;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            Toast.makeText(this, "You must be logged in to view your profile.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setupToolbar();
        loadUserData();
    }

    private void setupToolbar() {
        binding.toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void loadUserData() {
        db.collection("users").document(currentUser.getUid()).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        currentUserData = documentSnapshot.toObject(User.class);
                        if (currentUserData != null) {
                            populateUI();
                        }
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to load profile data.", Toast.LENGTH_SHORT).show());
    }

    private void populateUI() {
        // Set Header Info
        binding.tvUserName.setText(currentUserData.getName());
        binding.tvUserRoleDept.setText(currentUserData.getRole() + " @ " + currentUserData.getDepartment());

        // Create and set avatar initials
        String name = currentUserData.getName();
        if (name != null && !name.isEmpty()) {
            String[] names = name.split(" ");
            String initials = "";
            if (names.length > 0) {
                initials += names[0].charAt(0);
            }
            if (names.length > 1) {
                initials += names[names.length - 1].charAt(0);
            }
            binding.tvAvatarInitials.setText(initials.toUpperCase());
        }

        // Set display text values
        binding.tvDisplayName.setText(currentUserData.getName());
        String phone = currentUserData.getPhoneNumber() != null ? currentUserData.getPhoneNumber() : "Not set";
        binding.tvDisplayPhone.setText(phone);

        // Show/Hide Teacher Code section based on role
        if ("Teacher".equals(currentUserData.getRole())) {
            binding.teacherCodeSection.setVisibility(View.VISIBLE);
            String teacherCode = currentUserData.getTeacherCode();
            binding.tvDisplayTeacherCode.setText(teacherCode != null ? "Teacher Code: " + teacherCode : "Set Teacher Code");
        } else {
            // Students don't see teacher code section - it's handled at project level
            binding.teacherCodeSection.setVisibility(View.GONE);
        }
        
        // Setup click listeners now that we have the user data
        setupClickListeners();
    }

    private void setupClickListeners() {
        binding.btnEditName.setOnClickListener(v -> showEditFieldDialog("Full Name", "name", currentUserData.getName()));
        binding.btnEditPhone.setOnClickListener(v -> showEditFieldDialog("Phone Number", "phoneNumber", currentUserData.getPhoneNumber()));
        
        // Only handle teacher code click for teachers (students won't see this section)
        if ("Teacher".equals(currentUserData.getRole())) {
            binding.btnEditTeacherCode.setOnClickListener(v -> showTeacherCodeUpdateDialog());
        }
        
        binding.btnChangeEmail.setOnClickListener(v -> showChangeEmailDialog());
        binding.btnChangePassword.setOnClickListener(v -> showChangePasswordDialog());
    }

    // A reusable dialog for simple text fields
    private void showEditFieldDialog(String title, final String fieldKey, String currentValue) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update " + title);

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(currentValue);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newValue = input.getText().toString().trim();
            if (!newValue.isEmpty()) {
                db.collection("users").document(currentUser.getUid()).update(fieldKey, newValue)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(this, title + " updated.", Toast.LENGTH_SHORT).show();
                            loadUserData(); // Refresh the UI
                        })
                        .addOnFailureListener(e -> Toast.makeText(this, "Failed to update.", Toast.LENGTH_SHORT).show());
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Dialog for teachers to update their own teacher code
    private void showTeacherCodeUpdateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Teacher Code");
        final EditText input = new EditText(this);
        input.setHint("Enter new teacher code");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        String currentCode = currentUserData.getTeacherCode();
        if (currentCode != null) {
            input.setText(currentCode);
        }
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newCode = input.getText().toString().trim().toUpperCase();
            if (newCode.isEmpty()) {
                Toast.makeText(this, "Teacher code cannot be empty.", Toast.LENGTH_SHORT).show();
                return;
            }
            
            // Check if code is already used by another teacher
            db.collection("users")
                    .whereEqualTo("role", "Teacher")
                    .whereEqualTo("teacherCode", newCode)
                    .whereNotEqualTo("uid", currentUser.getUid())
                    .limit(1)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            Toast.makeText(this, "This teacher code is already in use by another teacher.", Toast.LENGTH_SHORT).show();
                        } else {
                            // Update the teacher's code
                            db.collection("users").document(currentUser.getUid())
                                    .update("teacherCode", newCode)
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(this, "Teacher code updated successfully.", Toast.LENGTH_SHORT).show();
                                        loadUserData();
                                    })
                                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to update teacher code.", Toast.LENGTH_SHORT).show());
                        }
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to validate teacher code.", Toast.LENGTH_SHORT).show());
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Dialog for students to link to a teacher using teacher-based codes
    private void showTeacherLinkDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Link to Teacher");
        final EditText input = new EditText(this);
        input.setHint("Enter Teacher Code");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        builder.setView(input);

        builder.setPositiveButton("Link", (dialog, which) -> {
            String code = input.getText().toString().trim().toUpperCase();
            if (code.isEmpty()) {
                // Unlink if the field is empty
                db.collection("users").document(currentUser.getUid()).update("teacherId", null)
                        .addOnSuccessListener(a -> {
                            Toast.makeText(this, "Unlinked from teacher.", Toast.LENGTH_SHORT).show();
                            loadUserData();
                        });
            } else {
                // Search for teacher with this code
                db.collection("users")
                        .whereEqualTo("role", "Teacher")
                        .whereEqualTo("teacherCode", code)
                        .limit(1)
                        .get()
                        .addOnSuccessListener(queryDocumentSnapshots -> {
                            if (queryDocumentSnapshots.isEmpty()) {
                                Toast.makeText(this, "Invalid Teacher Code.", Toast.LENGTH_SHORT).show();
                            } else {
                                // Found teacher, get the teacher ID
                                String teacherId = queryDocumentSnapshots.getDocuments().get(0).getString("uid");
                                String teacherName = queryDocumentSnapshots.getDocuments().get(0).getString("name");
                                
                                // Link student to teacher
                                db.collection("users").document(currentUser.getUid())
                                        .update("teacherId", teacherId)
                                        .addOnSuccessListener(a -> {
                                            Toast.makeText(this, 
                                                "Successfully linked to " + teacherName + "!", 
                                                Toast.LENGTH_SHORT).show();
                                            loadUserData();
                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(this, 
                                                "Failed to link to teacher.", 
                                                Toast.LENGTH_SHORT).show();
                                        });
                            }
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, 
                                "Failed to validate teacher code.", 
                                Toast.LENGTH_SHORT).show();
                        });
            }
        });
        builder.setNegativeButton("Cancel", (d, w) -> d.cancel());
        builder.show();
    }

    private void showChangePasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Change Password");
        final EditText input = new EditText(this);
        input.setHint("Enter new password");
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newPassword = input.getText().toString().trim();
            if (newPassword.length() < 6) {
                Toast.makeText(this, "Password must be at least 6 characters.", Toast.LENGTH_SHORT).show();
                return;
            }
            currentUser.updatePassword(newPassword)
                    .addOnSuccessListener(aVoid -> Toast.makeText(this, "Password updated successfully.", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to update password. Please sign out and sign in again.", Toast.LENGTH_LONG).show());
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Changing email is a sensitive action and requires re-authentication
    private void showChangeEmailDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Change Email Address");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_change_email, null);
        final EditText newEmailInput = dialogView.findViewById(R.id.et_new_email);
        final EditText passwordInput = dialogView.findViewById(R.id.et_current_password);
        builder.setView(dialogView);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newEmail = newEmailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (newEmail.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Both fields are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            AuthCredential credential = EmailAuthProvider.getCredential(currentUser.getEmail(), password);
            currentUser.reauthenticate(credential)
                    .addOnSuccessListener(aVoid -> {
                        currentUser.updateEmail(newEmail)
                                .addOnSuccessListener(aVoid2 -> {
                                    db.collection("users").document(currentUser.getUid()).update("email", newEmail);
                                    Toast.makeText(this, "Email updated successfully.", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> Toast.makeText(this, "Failed to update email.", Toast.LENGTH_SHORT).show());
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Authentication failed. Please check your password.", Toast.LENGTH_SHORT).show());
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}
