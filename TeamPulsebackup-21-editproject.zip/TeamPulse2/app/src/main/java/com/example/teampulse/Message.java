package com.example.teampulse;

import com.google.firebase.Timestamp;
import java.io.Serializable;

public class Message implements Serializable {
    private String id;
    private String senderId;
    private String senderName;
    private String text;
    private long timestamp;
    private String attachmentUrl; // Optional for future file attachments
    private String status; // sent, delivered, read
    private java.util.List<String> readBy; // user IDs who read the message
    private String replyToMessageId;
    private String replyToSenderName;
    private String replyPreviewText;
    private boolean isEdited = false;
    private boolean isDeleted = false;
    private long editedAt = 0;

    // Required empty constructor for Firestore
    public Message() {
    }

    public Message(String senderId, String senderName, String text, long timestamp) {
        this.senderId = senderId;
        this.senderName = senderName;
        this.text = text;
        this.timestamp = timestamp;
        this.status = "sent";
        this.readBy = new java.util.ArrayList<>();
        this.readBy.add(senderId);
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getAttachmentUrl() {
        return attachmentUrl;
    }

    public void setAttachmentUrl(String attachmentUrl) {
        this.attachmentUrl = attachmentUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public java.util.List<String> getReadBy() {
        return readBy;
    }

    public void setReadBy(java.util.List<String> readBy) {
        this.readBy = readBy;
    }

    public String getReplyToMessageId() {
        return replyToMessageId;
    }

    public void setReplyToMessageId(String replyToMessageId) {
        this.replyToMessageId = replyToMessageId;
    }

    public String getReplyToSenderName() {
        return replyToSenderName;
    }

    public void setReplyToSenderName(String replyToSenderName) {
        this.replyToSenderName = replyToSenderName;
    }

    public String getReplyPreviewText() {
        return replyPreviewText;
    }

    public void setReplyPreviewText(String replyPreviewText) {
        this.replyPreviewText = replyPreviewText;
    }

    public boolean isEdited() {
        return isEdited;
    }

    public void setEdited(boolean edited) {
        isEdited = edited;
        if (edited) {
            editedAt = System.currentTimeMillis();
        }
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public long getEditedAt() {
        return editedAt;
    }

    public void setEditedAt(long editedAt) {
        this.editedAt = editedAt;
    }
}