package com.example.teampulse;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.teampulse.databinding.ActivityTeacherDashboardBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TeacherDashboardActivity extends AppCompatActivity implements NavigationDrawerFragment.NavigationListener, NavigationDrawerFragment.DrawerActivity {

    private ActivityTeacherDashboardBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    private ListenerRegistration userListener;
    private List<Project> atRiskProjects = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTeacherDashboardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        setupViews();
        setupToolbarAndDrawer();
        setupBottomNavigation();
    }

    private void setupViews() {
        drawerLayout = findViewById(R.id.drawer_layout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardData();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (userListener != null) {
            userListener.remove();
        }
    }

    private void setupToolbarAndDrawer() {
        setSupportActionBar(binding.toolbar);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, binding.toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Host the NavigationDrawerFragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.drawer_fragment_container, new NavigationDrawerFragment())
                .commit();
    }

    private void loadDashboardData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            finish();
            return;
        }

        userListener = db.collection("users").document(currentUser.getUid()).addSnapshotListener((snapshot, e) -> {
            if (e != null) { return; }
            if (snapshot != null && snapshot.exists()) {
                String name = snapshot.getString("name");
                binding.tvWelcome.setText("Welcome, " + name + "!");
                invalidateOptionsMenu(); // Redraw menu to update avatar
            }
        });

        fetchAtRiskProjects(currentUser.getUid());
    }

    private void fetchAtRiskProjects(String teacherId) {
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        db.collection("projects")
                .whereEqualTo("teacherId", teacherId)
                .whereLessThan("deadline", todayDate)
                .whereLessThan("progress", 100)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    atRiskProjects.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Project project = doc.toObject(Project.class);
                        project.setId(doc.getId());
                        atRiskProjects.add(project);
                    }
                    updateAtRiskPanel();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load at-risk projects.", Toast.LENGTH_SHORT).show();
                    System.err.println("At-Risk Query Failed: " + e.getMessage());
                });
    }

    private void updateAtRiskPanel() {
        int count = atRiskProjects.size();
        binding.tvAtRiskCount.setText(String.valueOf(count));

        if (count > 0) {
            binding.btnViewAtRisk.setVisibility(View.VISIBLE);
            binding.btnViewAtRisk.setOnClickListener(v -> {
                Intent intent = new Intent(this, AtRiskProjectsActivity.class);
                intent.putExtra("AT_RISK_PROJECTS", (Serializable) atRiskProjects);
                startActivity(intent);
            });
        } else {
            binding.btnViewAtRisk.setVisibility(View.GONE);
            binding.btnViewAtRisk.setOnClickListener(null);
        }
    }

    private void logoutUser() {
        mAuth.signOut();
        Intent intent = new Intent(this, SignInActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.dashboard_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            db.collection("users").document(currentUser.getUid()).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            String name = documentSnapshot.getString("name");
                            MenuItem profileItem = menu.findItem(R.id.action_profile);
                            if (profileItem != null) {
                                View actionView = profileItem.getActionView();
                                if (actionView != null) {
                                    TextView avatarTextView = actionView.findViewById(R.id.avatar_text);
                                    if (name != null && !name.isEmpty()) {
                                        String[] names = name.split(" ");
                                        String initials = "";
                                        if (names.length > 0) initials += names[0].charAt(0);
                                        if (names.length > 1) initials += names[names.length - 1].charAt(0);
                                        avatarTextView.setText(initials.toUpperCase());
                                    }
                                    actionView.setOnClickListener(v -> onOptionsItemSelected(profileItem));
                                }
                            }
                        }
                    });
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        int itemId = item.getItemId();
        if (itemId == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupBottomNavigation() {
        binding.bottomNavigation.setSelectedItemId(R.id.nav_home);
        binding.bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                return true;
            } else if (itemId == R.id.nav_projects) {
                startActivity(new Intent(getApplicationContext(), TeacherProjectsActivity.class));
                overridePendingTransition(R.anim.float_up_in, R.anim.float_down_out);
                finish();
                return true;
            }
            return false;
        });
    }

    @Override
    public void onLogout() {
        logoutUser();
    }

    @Override
    public void onProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
    }

    @Override
    public void onActivityLog() {
        startActivity(new Intent(this, GlobalLogActivity.class));
    }

    @Override
    public void onSettings() {
        Toast.makeText(this, "Settings screen coming soon!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void closeDrawer() {
        drawerLayout.closeDrawer(GravityCompat.START);
    }
}